import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;

import java.util.List;
import java.util.ArrayList;

public class Game extends JFrame {
    // generation stuff
    private static PerlinNoise perlin = new PerlinNoise(9232993285l);

    private static double[][] noiseHeightMap = perlin.generateNoise(8400, 1, 50, 10);
    private static double[][] noiseCaveGen = perlin.generateNoise(8400, 2400, 60, 40);
    private static double[][] noiseBiomeGen = perlin.generateNoise(8400, 2400, 150, 300);

    // world stuff
    private static Player player = new Player(250, 10);
    public static Region[][] regions = new Region[84][24];

    // graphics handler
    private static GraphicsHandler graphics = new GraphicsHandler(noiseCaveGen, noiseBiomeGen, noiseHeightMap);

    // io stuff
    private static KeyMap keymap = new KeyMap();

    // delta time stuff
    private static long previousTime;
    //steps per frame
    private static int stepsPerFrame = 10;   

    // gravity
    private static double GRAVITY = 32;
    private static double TERMINAL_VELOCITY = 100;

    public static void main(String[] args) {

        
        // initialize frame and block sizes and the like

        JFrame frame = new JFrame("Terraria");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);

        graphics.setViewPort(frame);

        // make and add panel
        JPanel panel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2D = (Graphics2D) g;

                // drawPadding after drawBlocks to mask the sharp edges
                graphics.drawBlocks(g2D, player, regions);
                graphics.drawPlayer(g2D, player);
                graphics.drawPadding(g2D);
                g2D.setColor(Color.GREEN);
                g2D.drawString("" + player.getMomentumX(), 100, 100);
                g2D.drawString("" + player.getMomentumY(), 100, 200);

            }
        };
        frame.add(panel);
        panel.setFocusable(true); // Make sure the panel is focusable
        panel.requestFocusInWindow(); // Request focus for key events

        frame.setVisible(true);

        frame.addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                graphics.setViewPort(frame);
                frame.repaint(); // Repaint the frame when it is resized
            }
        });

        panel.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // detect keypress
                int keyCode = e.getKeyCode();
                keymap.pressKey(keyCode);
            }

            public void keyReleased(KeyEvent e) {
                // detect keypress
                int keyCode = e.getKeyCode();
                keymap.releaseKey(keyCode);
            }

            public void keyTyped(KeyEvent e) {
            };
        });
        Timer timer = new Timer(16, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // calculate change in time dt from current time - previous time to get time
                // between frames.
                // use this number to determine how far the player moved.
                float dt = (System.nanoTime() - previousTime) / 1_000_000_000.0f;
                Map<Integer, Boolean> keyStates = keymap.getKeyStates();
                // movement logic based on key states

                // update player's onBlock
                player.updateOnBlock(regions);

                // update momentum

                // first apply friction. This will only affect x momentum.
                player.setMomentumX(applyFriction(player.getMomentumX(), getFriction(player) * dt));
                // then apply gravity
                if (!player.isOnGround()) {
                    player.setMomentumY(applyGravity(player.getMomentumY(), GRAVITY * dt));
                } else {
                    //player.setMomentumY(0);
                }

                // now change momentum based on keystates
                if (keyStates.get(87)) { // 'W' key (keycode 87)
                    if (player.isOnGround()) {
                        player.setMomentumY(-20); // Move up
                    }
                }
                if (keyStates.get(83)) { // 'S' key (keycode 83)
                    // player.setMomentumY(player.getMomentumY() + player.getSpeed() * dt); // Move
                    // down
                }
                if (keyStates.get(65)) { // 'A' key (keycode 65)
                    player.setMomentumX(player.getMomentumX() - player.getSpeed() * dt); // Move left
                }
                if (keyStates.get(68)) { // 'D' key (keycode 68)
                    player.setMomentumX(player.getMomentumX() + player.getSpeed() * dt); // Move right
                }

                double newX = player.getX();
                double newY = player.getY();
                // actual move. done in x and y separately to allos for sliding
                
                newX = player.getX() + player.getMomentumX() * dt;
                newY = player.getY() + player.getMomentumY() * dt;

                double[] newXY = CollisionUtil.attemptMove(newX, newY, player, regions);
                if (newXY[0] != newX) {
                    // if there was a collision then reset the players momentum. Same for y
                    player.setMomentumX(0);
                }
                if (newXY[1] != newY) {
                    player.setMomentumY(0);
                }
                player.setX(newXY[0]);
                player.setY(newXY[1]);

                // repaint
                panel.repaint();
                previousTime = System.nanoTime();
            }
        });

        // initialize timer
        previousTime = System.nanoTime();
        timer.start();
    }

    /**
     * 
     * @param x in blocks
     * @param y in blocks
     * @return region x, y
     */
    public static int[] getRegionXY(double x, double y) {
        int[] out = new int[2];
        out[0] = (int) Math.floor((x) / 100);
        out[1] = (int) Math.floor((y) / 100);
        return out;
    }

    /**
     * 
     * @param x in blocks
     * @param y in blocks
     * @return block index in region
     */
    public static int[] getBlockXY(double x, double y) {
        int[] out = new int[2];
        out[0] = (int) Math.floor((x) % 100);
        out[1] = (int) Math.floor((y) % 100);
        return out;
    }

    public static boolean coordsInBounds(int x, int y) {
        boolean out = false;
        if (x >= 0 && y >= 0 && x < regions.length && y < regions[0].length) {
            out = true;
        }
        return out;
    }

    public static double getFriction(Player player) {
        double out = 0;
        String[] blocks = player.getBlocksBelow();
        for (int i = 0; i < blocks.length; i++) {
            if (blocks[i].equals("wall")) {
                out = 40 > out ? 40 : out;
            }
        }
        return out;
    }

    public static double applyFriction(double momentum, double friction) {
        double out = 0;
        // if its 0 don't change the momentum. Friction works until 0
        if (momentum != 0) {
            if (momentum < 0) {
                // momentum is negative. Add friction. If its greater than 0 after adding then
                // instead make it 0;
                double newMomentum = momentum + friction;
                out = newMomentum < 0 ? newMomentum : 0;
            } else {
                // momentum is positive. subtract friction, then if less than 0 set to 0 instead
                double newMomentum = momentum - friction;
                out = newMomentum > 0 ? newMomentum : 0;
            }
        }
        return out;
    }

    public static double applyGravity(double momentum, double gravity) {
        double out = momentum;

        // add gravity to momentum
        double changedMomentum = momentum + gravity;
        // check that new momentum is less than terminal velocity. If not set to the
        // limit.

        out = changedMomentum < TERMINAL_VELOCITY ? changedMomentum : TERMINAL_VELOCITY;
        return out;

    }
}

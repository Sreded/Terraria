import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class CollisionUtil {
    /**
     * checks left of x1
     * 
     * @param x1
     * @param w1
     * @param x2
     * @param w2
     * @return
     */

    public static boolean isCollidingSquare(double x1, double y1, double w1, double h1, double x2, double y2, double w2,
            double h2) {
        boolean out = false;
        if (x1 + w1 > x2 && x1 < x2 + w2
                && y1 + h1 > y2 && y1 < y2 + h2) {
            out = true;
        }
        return out;
    }

    /**
     * gets the side of the collision in a simple rectangular collision. The side is
     * relative to rect 1
     * 
     * @return and enum with one of the sides
     */
    public static CollisionData.Sides rectCollisionGetSide(double x1, double y1, double w1, double h1, double x2,
            double y2, double w2,
            double h2) {
        CollisionData.Sides side;
        // get dists between respecitve sides
        double offsetX = Math.min(x1 + w1 - x2, x2 + w2 - x1);
        double offsetY = Math.min(y1 + h1 - y2, y2 + h2 - y1);

        if (offsetX <= offsetY) {
            if (x1 + w1 / 2 <= x2 + w2 / 2) {
                side = CollisionData.Sides.RIGHT;
            } else {
                side = CollisionData.Sides.LEFT;
            }
        } else {
            if (y1 + h1 / 2 <= y2 + h2 / 2) {
                side = CollisionData.Sides.BOTTOM;
            } else {
                side = CollisionData.Sides.TOP;
            }
        }
        return side;

    }

    /**
     * 
     * @param w1 must be positive
     * @param h1 must be positive
     * @returns CollisionData with all the stats. CollisionData.getSides() will
     *          contain side from block's perspective
     */

    public static boolean isCollidingLineLine(double x1, double y1, double x2, double y2, double x3, double y3,
            double x4, double y4) {
        boolean out = false;
        // get slopes
        double m1 = x2 - x1 == 0 ? Double.POSITIVE_INFINITY : (y2 - y1) / (x2 - x1);
        double m2 = x4 - x3 == 0 ? Double.POSITIVE_INFINITY : (y4 - y3) / (x4 - x3);
        // y = mx + b
        // given y and x and m
        // b = y-mx
        if (m1 == m2 && y1 - m1 * x1 == y3 - m2 * x3) {
            // lines identical

            // make sure they overlap
            if (Math.max(x1, x2) >= Math.min(x3, x4) && Math.min(x1, x2) <= Math.max(x3, x4) &&
                    Math.max(y1, y2) >= Math.min(y3, y4) && Math.min(y1, y2) <= Math.max(y3, y4)) {
                out = true;
            }
        } else {
            // i don't understand determinants for matrixes, so the math is beyond me here.
            // Do need to still make sure not dividing by 0
            double denominator = (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);
            if (denominator != 0) {
                // calculate the distance to intersection point
                double uA = ((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3))
                        / denominator;
                double uB = ((x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3))
                        / denominator;

                // if uA and uB are between 0-1, lines are colliding. (Because it is parameter
                // for parametric equations)
                if (uA >= 0 && uA <= 1 && uB >= 0 && uB <= 1) {

                    out = true;
                }
            }
        }
        return out;
    }

    public static boolean isCollidingLineSquare(double[] p1, double[] p2, double x1, double y1, double w1,
            double h1) {

        boolean collision = false;

        // first do a quick check to see if the line is completely inside the box. If it
        // is, then don't do the second part since there weren't any intersections.
        if ((p1[0] >= x1 && p1[0] <= x1 + w1 && p1[1] >= y1 && p1[1] <= y1 + h1)
                || (p2[0] >= x1 && p2[0] <= x1 + w1 && p2[1] >= y1 && p2[1] <= y1 + h1)) {
            collision = true;
        } else {

            // get the sides of the box

            double[][] topLine = { { x1, y1 }, { x1 + w1, y1 } };
            double[][] leftLine = { { x1, y1 }, { x1, y1 + h1 } };
            double[][] bottomLine = { { x1, y1 + h1 }, { x1 + w1, y1 + h1 } };
            double[][] rightLine = { { x1 + w1, y1 }, { x1 + w1, y1 + h1 } };

            double[][][] sides = { topLine, leftLine, bottomLine, rightLine };

            for (int i = 0; i < 4; i++) {
                double[][] line = sides[i];
                if (isCollidingLineLine(p1[0], p1[1], p2[0], p2[1], line[0][0], line[0][1], line[1][0], line[1][1])) {
                    collision = true;
                }
            }
        }
        return collision;

    }

    public static double[] attemptMove(double attemptX, double attemptY, Player player, Region[][] regions) {
        // System.out.println(rectCollisionGetSide(0, 0, 5, 10, 9, 8, 10, 300));

        double[] out = { player.getX(), player.getY() };
        // get the four lines between the start and end boxes. these are sweep lines

        // corners1 has corners of old position
        double[][] corners1 = {
                { player.getX(), player.getY() },
                { player.getX() + player.getWidth(), player.getY() },
                { player.getX(), player.getY() + player.getHeight() },
                { player.getX() + player.getWidth(), player.getY() + player.getHeight() }
        };

        // corners 2 has corners of new position

        double[][] corners2 = {
                { attemptX, attemptY },
                { attemptX + player.getWidth(), attemptY },
                { attemptX, attemptY + player.getHeight() },
                { attemptX + player.getWidth(), attemptY + player.getHeight() }
        };

        // lines is structured 4 lines, 2 points for a line, x and y for those points
        double[][][] lines = new double[4][2][2];

        for (int i = 0; i < lines.length; i++) {
            double[] p1 = { corners1[i][0], corners1[i][1] };
            double[] p2 = { corners2[i][0], corners2[i][1] };
            lines[i][0] = p1;
            lines[i][1] = p2;
        }

        // check against all boxes in a 10x10 vicinity to see if there are any
        // intersections with the lines. add the colliding boxes to a list.
        boolean collision = false;
        List<CollidingBlock> collidingBlocks = new ArrayList<CollidingBlock>();

        for (int i = -5; i < 5; i++) {
            for (int j = -5; j < 5; j++) {
                int[] regionXY = Game.getRegionXY(attemptX + i, attemptY + j);

                int[] blockXY = Game.getBlockXY(attemptX + i, attemptY + j);
                String block = "air";

                if (Game.coordsInBounds(regionXY[0], regionXY[1])) {
                    block = regions[regionXY[0]][regionXY[1]].getBlocks()[blockXY[0]][blockXY[1]];
                }

                if (!block.equals("air")) {
                    for (int k = 0; k < lines.length; k++) {

                        boolean isColliding = isCollidingLineSquare(lines[k][0], lines[k][1],
                                blockXY[0] + regionXY[0] * 100,
                                blockXY[1] + regionXY[1] * 100,
                                1, 1);

                        if (isColliding) {
                            collidingBlocks.add(new CollidingBlock(blockXY[0] + regionXY[0] * 100,
                                    blockXY[1] + regionXY[1] * 100,
                                    lines[k], CollidingBlock.Corners.TL));
                            collision = true;
                        }
                    }
                }
            }
        }
        if (!collision) {
            out[0] = attemptX;
            out[1] = attemptY;
        } else {
            // go through the list and handle the collision
            // will handle based on line trajectory.
            double[] lineVector = { lines[0][1][0] - lines[0][0][0], lines[0][1][1] -
                    lines[0][0][1] };
            // sort by closest coordinates. cloesest will be the first collision, if
            // multiple both will be handled
            // double lowestXYSum = Double.POSITIVE_INFINITY;

            List<CollidingBlock> firstCollisions = new ArrayList<CollidingBlock>();

            double lowestDist = Double.POSITIVE_INFINITY;
            for (int i = 0; i < collidingBlocks.size(); i++) {
                CollidingBlock block = collidingBlocks.get(i);
                // distance between player and block center
                double dist = Math.sqrt(Math.pow(player.getX() + player.getWidth() / 2 - block.getX() + 0.5, 2)
                        + Math.pow(player.getY() + player.getHeight() / 2 - block.getY() + 0.5, 2));
                if (dist == lowestDist) {
                    firstCollisions.add(block);
                } else if (dist < lowestDist) {
                    lowestDist = dist;
                    firstCollisions.clear();
                    firstCollisions.add(block);
                }
            }
            // calculate t from x values in parametric equation

            CollidingBlock firstCollision = collidingBlocks.get(0);
            double[][] line = firstCollision.getLine();
            double[][] TLline = lines[0];
            CollidingBlock.Corners corner = firstCollision.getCorner();
            System.out.println(Arrays.toString(line[0]) + ", " +Arrays.toString(line[1]) + ", " + firstCollision.getX() + ", "+ firstCollision.getY()+ ", 1, 1");
            double t = getTofLineRectCollision(line[0], line[1], firstCollision.getX(), firstCollision.getY(), 1, 1);
            // go a tiny bit past the first point of collision
            System.out.println(t);
            t += 0.001;
            
            // now use t to get position on top left corner line

            double[] v = { TLline[1][0] - TLline[0][0], TLline[1][1] - TLline[0][1] };

            double x = TLline[0][0] + t * v[0];
            double y = TLline[0][1] + t * v[1];
            System.out.println((x+player.getWidth()) +", " + (y+player.getHeight()));
            double playerCollisionX = x - player.getWidth();
            double playerCollisionY = y - player.getHeight();
            // these translate collision intersection coordinates to player coordinates
            /*
             * if (player.getMomentumX() > 0) {
             * playerCollisionX -= player.getWidth();
             * } else if (player.getMomentumX() < 0) {
             * playerCollisionX += player.getWidth();
             * }
             * if (player.getMomentumY() > 0) {
             * playerCollisionY -= player.getHeight();
             * } else if (player.getMomentumY() < 0) {
             * playerCollisionY += player.getHeight();
             * }
             */
            // now get collision side and handle collision
            CollisionData.Sides side = rectCollisionGetSide(playerCollisionX, playerCollisionY, player.getWidth(),
                    player.getHeight(), firstCollision.getX(), firstCollision.getY(), 1, 1);
            System.out.println(side);
            if (side == CollisionData.Sides.BOTTOM) {
                out[0] = attemptX;
                out[1] = firstCollision.getY() - player.getHeight() - 0.01;
            } else if (side == CollisionData.Sides.TOP) {
                out[0] = attemptX;
                out[1] = firstCollision.getY() + 1.01;
            } else if (side == CollisionData.Sides.LEFT) {
                out[0] = firstCollision.getX() + 1.01;
                out[1] = attemptY;

            } else {
                out[0] = firstCollision.getX() - player.getWidth() - 0.01;
                out[1] = attemptY;
            }
            // get x and y of first collision based on the

            /*
             * if (firstCollision.getSide() == CollisionData.Sides.RIGHT) {
             * 
             * out[0] = firstCollision.getX() + 1.01;
             * 
             * boolean topBlockInX = false;
             * int topBlockY = -1;
             * boolean bottomBlockInX = false;
             * int bottomBlockY = -1;
             * for (int i = 0; i < collidingBlocks.size(); i++) {
             * int minX = (int) Math.floor(player.getX());
             * int maxX = (int) Math.floor(player.getX() + player.getWidth());
             * CollidingBlock block = collidingBlocks.get(i);
             * if (block.getX() >= minX && block.getX() <= maxX) {
             * if (block.getSide() == CollisionData.Sides.BOTTOM) {
             * bottomBlockInX = true;
             * bottomBlockY = block.getY();
             * } else if (block.getSide() == CollisionData.Sides.TOP) {
             * topBlockInX = true;
             * topBlockY = block.getY();
             * }
             * }
             * }
             * if (topBlockInX) {
             * out[1] = topBlockY - player.getHeight() - 0.01;
             * } else if (bottomBlockInX) {
             * out[1] = bottomBlockY + 1.01;
             * } else {
             * out[1] = attemptY;
             * }
             * /*
             * /
             * if (lineVector[0] != 0) {
             * double slope = lineVector[1] / lineVector[0];
             * out[1] = slope * out[0] + lines[0][0][1];
             * } else {
             * out[1] = firstCollision.getY() - player.getHeight() - 0.01;
             * }
             * 
             * 
             * } else if (firstCollision.getSide() == CollisionData.Sides.LEFT) {
             * out[0] = firstCollision.getX() - player.getWidth() - 0.01;
             * out[1] = attemptY;
             * if (lineVector[0] != 0) {
             * double slope = lineVector[1] / lineVector[0];
             * out[1] = slope * out[0] + lines[0][0][1];
             * }
             * } else if (firstCollision.getSide() == CollisionData.Sides.TOP) {
             * out[0] = attemptX;
             * out[1] = firstCollision.getY() - player.getHeight() - 0.01;
             * } else {
             * // bottom
             * out[0] = attemptX;
             * out[1] = firstCollision.getY() + 1.01;
             * }
             */

        }
        /*
         * double[] lineVector = { lines[0][1][0] - lines[0][0][0], lines[0][1][1] -
         * lines[0][0][1] };
         * System.out.println(lineVector[0]);
         * if (lineVector[0] >= 0 && lineVector[1] >= 0) {
         * // ++ direction
         * System.out.println("++ direction");
         * //collidingBlocks.sort((a, b) -> Double.compare(a[0], b[0]));
         * // make sure that the colliding block is to the player's right, not beneath
         * for (int i = 0; i < collidingBlocks.size(); i++) {
         * if (collidingBlocks.get(0).getY() <= Math.floor(attemptY)
         * && collidingBlocks.get(0).getY() >= Math.ceil(attemptY) + player.getHeight())
         * {
         * out[0] = collidingBlocks.get(0).getX() - 1.01;
         * System.out.println("error");
         * break;
         * }
         * }
         * //collidingBlocks.sort((a, b) -> Double.compare(a[1], b[1]));
         * if (collidingBlocks.get(0).getX() >= Math.floor(attemptX)
         * && collidingBlocks.get(0).getX() <= Math.ceil(attemptX) + player.getWidth())
         * out[1] = collidingBlocks.get(0).getY() - player.getHeight() - 0.01;
         * } else if (lineVector[0] < 0 && lineVector[1] >= 0) {
         * // -+ direction
         * System.out.println("-+ direction");
         * } else if (lineVector[0] >= 0 && lineVector[1] < 0) {
         * // +- direction
         * // out[0] =
         * System.out.println("+- direction");
         * } else {
         * // --
         * System.out.println("-- direction");
         * }
         * }
         */
        // out[0] = attemptX;
        // out[1] = attemptY;
        return out;

    }

    /** it is given that the line and rect already collide */
    public static double getTofLineRectCollision(double[] p1, double[] p2, double x1, double y1, double w1, double h1) {
        double closestT = Double.POSITIVE_INFINITY;

        // left, right
        // double[] xSides = { x1, x1 + w1 };
        // top, bottom
        // double[] ySides = { y1, y1 + h1 };

        // double denominator = p2[0] - p1[0];
        // if(denominator != 0) {
        double[] v = { p2[0] - p1[0], p2[1] - p1[1] };

        // vertical line case
        if (v[0] == 0) {
            // get y t
            // top
            double t = (y1 - p1[1]) / v[1];
            if (t <= 1 && t >= 0) {
                if (t < closestT) {
                    closestT = t;
                }
            }
            // bottom
            t = (y1 + h1 - p1[1]) / v[1];
            if (t <= 1 && t >= 0) {
                if (t < closestT) {
                    closestT = t;
                }
            }
        } else if (v[1] == 0) {
            // left
            double t = (x1 - p1[0]) / v[0];
            if (t <= 1 && t >= 0) {
                if (t < closestT) {
                    closestT = t;
                }
            }
            // right
            t = (x1 + w1 - p1[0]) / v[0];
            if (t <= 1 && t >= 0) {
                if (t < closestT) {
                    closestT = t;
                }
            }
        } else {
            // top
            double t = (y1 - p1[1]) / v[1];
            if (t <= 1 && t >= 0) {
                double xInt = p1[0] + t * v[0];
                if (xInt >= x1 && xInt <= x1 + w1) {
                    if (t < closestT) {
                        closestT = t;
                    }
                }
            }
            // bottom
            t = (y1 + h1 - p1[1]) / v[1];
            if (t <= 1 && t >= 0) {
                double xInt = p1[0] + t * v[0];
                if (xInt >= x1 && xInt <= x1 + w1) {
                    if (t < closestT) {
                        closestT = t;
                    }
                }
            }
            // left
            t = (x1 - p1[0]) / v[0];
            if (t <= 1 && t >= 0) {
                double yInt = p1[1] + t * v[1];
                if (yInt >= y1 && yInt <= y1 + h1) {
                    if (t < closestT) {
                        closestT = t;
                    }
                }
            }
            // right
            t = (x1 + w1 - p1[0]) / v[0];
            if (t <= 1 && t >= 0) {
                double yInt = p1[1] + t * v[1];
                if (yInt >= y1 && yInt <= y1 + h1) {
                    if (t < closestT) {
                        closestT = t;
                    }
                }
            }
        }
    
        return closestT;
    }

    private static double[] handleVerical(double tryY, Player player, List<double[]> collidingBlocks,
            Region[][] regions,
            double[] currentXY) {
        double[] out = currentXY;

        // get direction on y axis
        double directionY = tryY - player.getY();

        if (directionY != 0) {
            if (directionY < 0) {
                // moved up: Sort colliding blocks by y-coordinate (ascending)
                collidingBlocks.sort((a, b) -> Double.compare(b[1], a[1]));
                double[] upBlock = collidingBlocks.get(0);
                out[1] = upBlock[1] + 1.01; // Adjust position to the bottom of the block

            } else {
                // moved down: Sort colliding blocks by y-coordinate (descending)
                collidingBlocks.sort((a, b) -> Double.compare(a[1], b[1]));
                double[] downBlock = collidingBlocks.get(0);
                out[1] = downBlock[1] - player.getHeight() - 0.01; // adjust position such that bottom of player
                                                                   // hits the top of the block

            }
        }
        return out;
    }

    private static double[] handleHorizontal(double tryX, Player player, List<double[]> collidingBlocks,
            Region[][] regions, double[] currentXY) {
        double[] out = currentXY;

        // direction of movement X
        double directionX = tryX - player.getX();

        if (directionX != 0) {
            if (directionX < 0) {
                // Moved left: Sort colliding blocks by x-coordinate (ascending)
                collidingBlocks.sort((a, b) -> Double.compare(a[0], b[0]));
                double[] leftBlock = collidingBlocks.get(0);

                // check if the block colliding with is at player's feet and player is on ground
                if (player.isOnGround() && leftBlock[1] == Math.floor(player.getY() + player.getHeight())) {
                    // also check there is free space above
                    boolean obstructed = false;

                    for (int i = 1; i < player.getHeight() + 2; i++) {
                        // get coords of block
                        int[] regionXY = Game.getRegionXY(leftBlock[0], leftBlock[1] - i);
                        int[] blockXY = Game.getBlockXY(leftBlock[0], leftBlock[1] - i);
                        // if they exist, check again. If not its empty space
                        if (Game.coordsInBounds(regionXY[0], regionXY[1])) {
                            if (!regions[regionXY[0]][regionXY[1]].getBlocks()[blockXY[0]][blockXY[1]]
                                    .equals("air")) {
                                // if there is a block in the way obstructed is truye
                                obstructed = true;
                            }
                        }
                    }
                    // if not obstructed set x and y to the correct coordinates
                    if (!obstructed) {
                        out[0] = tryX;
                        out[1] = leftBlock[1] - player.getHeight() - 0.01;
                    }
                } else {
                    // not eleigible to walk up ledge. Normal logic
                    out[0] = leftBlock[0] + 1.01; // Adjust position to the right side of the block

                }

            } else {
                // Moved right: Sort colliding blocks by x-coordinate (descending)
                collidingBlocks.sort((a, b) -> Double.compare(b[0], a[0]));
                double[] rightBlock = collidingBlocks.get(0);

                // check if the block colliding with is at player's feet and they are on ground
                if (player.isOnGround() && rightBlock[1] == Math.floor(player.getY() + player.getHeight())) {
                    // also check there is free space above
                    boolean obstructed = false;

                    for (int i = 1; i < player.getHeight() + 2; i++) {
                        // get coords of block
                        int[] regionXY = Game.getRegionXY(rightBlock[0], rightBlock[1] - i);
                        int[] blockXY = Game.getBlockXY(rightBlock[0], rightBlock[1] - i);
                        // if they exist, check again. If not its empty space
                        if (Game.coordsInBounds(regionXY[0], regionXY[1])) {
                            if (!regions[regionXY[0]][regionXY[1]].getBlocks()[blockXY[0]][blockXY[1]]
                                    .equals("air")) {
                                // if there is a block in the way obstructed is truye
                                obstructed = true;
                            }
                        }
                    }
                    // if not obstructed set x and y to the correct coordinates
                    if (!obstructed) {
                        out[0] = tryX;
                        out[1] = rightBlock[1] - player.getHeight() - 0.01;
                    }
                } else {
                    // not eleigible to walk up ledge. Normal logic
                    out[0] = rightBlock[0] - player.getWidth() - 0.01; // Adjust position to the left side of the
                    // block
                }

            }
        }
        return out;
    }
}

// container class for collidingBlocks
class CollidingBlock {
    private int x;
    private int y;
    private double t;
    private CollisionData.Sides side;
    private double[][] line;
    private Corners corner;

    public enum Corners {
        TL,
        BR,
        BL,
        TR
    }

    public CollidingBlock(int x, int y, double[][] line, Corners corner) {
        this.x = x;
        this.y = y;
        this.corner = corner;
        this.line = line;
    }

    /**
     * gets the top left corner
     * 
     * @param a
     * @param b
     * @return
     */
    // public static int compareTL(CollidingBlock a, CollidingBlock b) {
    // int out = 0;
    // if (a.getX() > b.getX()) {
    // out = 1;
    // } else if (a.getT() < b.getT()) {
    // out = -1;
    // }
    // return out;
    // }

    // getter for 'line'
    public double[][] getLine() {
        return line;
    }

    // Getter for 'x'
    public int getX() {
        return x;
    }

    // Getter for 'y'
    public int getY() {
        return y;
    }

    // Getter for 't'
    public Corners getCorner() {
        return corner;
    }

    // Getter for 'side'
    public CollisionData.Sides getSide() {
        return side;
    }

}

class CollisionData {
    public enum Sides {
        LEFT,
        RIGHT,
        TOP,
        BOTTOM
    }

    private boolean collision;
    private double t;
    private Sides side;

    public CollisionData(boolean collision, double t, Sides side) {
        this.collision = collision;
        this.t = t;
        this.side = side;
    }

    // Getter for 'collision'
    public boolean isCollision() {
        return collision;
    }

    // Setter for 'collision'
    public void setCollision(boolean collision) {
        this.collision = collision;
    }

    // Getter for 't'
    public double getT() {
        return t;
    }

    // Setter for 't'
    public void setT(double t) {
        this.t = t;
    }

    // Getter for 'side'
    public Sides getSide() {
        return side;
    }

    // Setter for 'side'
    public void setSide(Sides side) {
        this.side = side;
    }

}
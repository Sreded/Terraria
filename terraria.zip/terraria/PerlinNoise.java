//Credit to chatGPT on this file - i did not make it. I couldn't figure out perlin noise for the life of me.

import java.util.Random;

public class PerlinNoise {
    private int[] p; // Permutation table
    private int[] perm; // Shuffled permutation table
    private int[] grad; // Gradient vectors

    public PerlinNoise(long seed) {
        p = new int[512];
        perm = new int[512];
        grad = new int[512];

        // Create permutation table
        for (int i = 0; i < 256; i++) {
            p[i] = i;
        }

        // Shuffle the table
        Random rand = new Random(seed);
        for (int i = 0; i < 256; i++) {
            int swap = rand.nextInt(256);
            int temp = p[i];
            p[i] = p[swap];
            p[swap] = temp;
        }

        // Repeat the permutation table
        for (int i = 0; i < 256; i++) {
            perm[i] = p[i];
            perm[i + 256] = p[i];
        }

        // Gradient vectors
        for (int i = 0; i < 256; i++) {
            grad[i] = rand.nextInt(4); // Random gradients from 0 to 3
        }
    }

    // Smooths the input t to make it ease-in and ease-out
    private double fade(double t) {
        return t * t * t * (t * (t * 6 - 15) + 10);
    }

    // Linearly interpolates between a and b
    private double lerp(double a, double b, double t) {
        return a + t * (b - a);
    }

    // Dot product of (x, y) and gradient (gx, gy)
    private double gradDot(int hash, double x, double y) {
        int h = hash & 15;
        double gradValue = 1.0 + (h & 7); // Gradient magnitude
        if ((h & 8) != 0)
            gradValue = -gradValue; // Invert the gradient if needed

        // Compute the dot product
        return gradValue * x + gradValue * y;
    }

    // Generates Perlin noise at coordinates (x, y)
    public double noise(double x, double y) {
        // Find grid cell coordinates
        int X = (int) Math.floor(x) & 255;
        int Y = (int) Math.floor(y) & 255;

        // Relative position in grid cell
        double xf = x - Math.floor(x);
        double yf = y - Math.floor(y);

        // Fade curves for easing the interpolation
        double u = fade(xf);
        double v = fade(yf);

        // Hash values for the four corners
        int aa = perm[X + perm[Y]];
        int ab = perm[X + perm[Y + 1]];
        int ba = perm[X + 1 + perm[Y]];
        int bb = perm[X + 1 + perm[Y + 1]];

        // Interpolate between corners
        double x1 = lerp(gradDot(aa, xf, yf), gradDot(ba, xf - 1, yf), u);
        double x2 = lerp(gradDot(ab, xf, yf - 1), gradDot(bb, xf - 1, yf - 1), u);

        return lerp(x1, x2, v); // Final interpolation between x1 and x2
    }

    // Generates a Perlin noise 2D grid (for visualization)
    public double[][] generateNoise(int width, int height, double scaleX, double scaleY) {
        double[][] noise = new double[width][height];
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                noise[x][y] = noise(x / scaleX, y / scaleY); // Scale the coordinates
            }
        }
        return normalize(noise);
    }

    private double[][] normalize(double[][] noise) {
        double[][] out = new double[noise.length][noise[0].length];
        double max = -100.0;
        double min = 100.0;
        double absExtrema;
        // get the min and max of the noise values
        for (int i = 0; i < noise.length; i++) {
            for (int j = 0; j < noise[0].length; j++) {
                double value = noise[i][j];
                if (value > max) {
                    max = value;
                }
                if (value < min) {
                    min = value;
                }
            }
        }
        // pick the furtherst away from 0 as the extrema
        absExtrema = max > Math.abs(min) ? max : Math.abs(min);
        // now normalize every value by dividing them by this
        for (int i = 0; i < noise.length; i++) {
            for (int j = 0; j < noise[0].length; j++) {
                out[i][j] = noise[i][j] / absExtrema;
            }
        }
        return out;
    }

}

public class BiomeMap {
    private String[][] map;
    private int width;
    private int height;

    /**
     * 
     * @param regionX coordinates in regions (100 blocks).
     * @param regionY coordinates in regions (100 blocks).
     */
    public BiomeMap(int width, int height, double[][] noiseBiomeGen, int regionX, int regionY) {
        this.width = width;
        this.height = height;
        // make blank map
        map = new String[width - 1][height - 1];
        // populate map
        map = generateBiomes(map, noiseBiomeGen, regionX, regionY);

        // visualize(map);

    }

    // for corruption chasms will find middle of corruption biome at surface then
    // dig chasms and set surrounding blocks to corruption

    private String[][] generateBiomes(String[][] map, double[][] noiseBiomeGen, int regionX, int regionY) {
        // biomes: jungle, forest, corruption, underground desert, underground ice

        // make noise
        // large scale so biomes are large
        double[][] noise = ArrayUtil.extractSubarrayD(noiseBiomeGen, regionX * width, regionY * height,
                regionX * width + width, regionY * height + height);
        // initial thresholds. Will change since some biomes don't spawn at surface
        double[] thresholds = { 0.25, -0.5, -1.1, -2.2 };
        // iterate through every point in the bioome map
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[0].length; j++) {
                String biome;

                // use biomes to check which biome a noise value equates to
                if (noise[i][j] > thresholds[0]) {
                    biome = "forest";
                } else if (noise[i][j] > thresholds[1]) {
                    biome = "jungle";
                } else if (noise[i][j] > thresholds[2]) {
                    biome = "corruption";
                } else if (noise[i][j] > thresholds[3]) {
                    biome = "ujungle";
                } else {
                    biome = "uice";
                }

                map[i][j] = biome;

            }
            // increase the first three weights to allow for more underground biomes to
            // spawn
            thresholds[0] = addFunc(thresholds[0], 1.0, 0.005);

            thresholds[1] = addFunc(thresholds[1], 1.0, 0.01);

            thresholds[2] = addFunc(thresholds[2], 1.0, 0.02);

            // now increase the threshold between the two cave biomes until its a 50 50
            // chance.

            thresholds[3] += thresholds[3] < 0 ? 0.1 : 0.0;
        }
        return map;
    }

    // function that adds additive unless x is greater than limit
    private double addFunc(double x, double limit, double additive) {
        return x < limit ? x + additive : x;
    }

    private void visualize(String[][] map) {
        // iterate through and print a symbol corresponding to each biome
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[0].length; j++) {
                switch (map[i][j]) {
                    case "forest":
                        System.out.println("#");
                        break;
                    case "jungle":
                        System.out.println("*");
                        break;
                    case "corruption":
                        System.out.println("$");
                        break;
                    case "udesert":
                        System.out.println("^");
                        break;
                    case "uice":
                        System.out.println("%");
                        break;
                }
                System.out.print(map[i][j]);
            }
            System.out.println();
        }
    }
}

public class Player {
    private double x;
    private double y;
    private int width = 2;
    private int height = 3;

    private double momentumX = 0;
    private double momentumY = 0;

    private float speed;
    private float maxSpeed;

    private boolean onGround = false;
    private String[] onBlock = { "air" };

    public Player(int x, int y) {
        this.x = (double) x;
        this.y = (double) y;
        // usually 10
        speed = 80;
        maxSpeed = 10;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }

    public float getSpeed() {
        return speed;
    }

    public float getMaxSpeed() {
        return maxSpeed;
    }

    public double getMomentumX() {
        return momentumX;
    }

    public void setMomentumX(double momentum) {
        if (momentum >= 0) {
            momentumX = momentum > maxSpeed ? maxSpeed : momentum;
        } else {
            momentumX = momentum < -maxSpeed ? -maxSpeed : momentum;
        }
    }

    public double getMomentumY() {
        return momentumY;
    }

    public void setMomentumY(double momentum) {
        /*
         * if (momentum >= 0) {
         * momentumY = momentum > maxSpeed ? maxSpeed : momentum;
         * } else {
         * momentumY = momentum < -maxSpeed ? -maxSpeed : momentum;
         * }
         */
        momentumY = momentum;
    }

    public boolean isOnGround() {
        return onGround;
    }

    /**
     * returns which block the player is above. Whichever is closest to player
     */
    public String[] getBlocksBelow() {
        return onBlock;
    }

    public void updateOnBlock(Region[][] regions) {

        boolean isOnBlock = false;
        int blocksToCheck = Math.round(x*1000)/1000 % 1 == 0 ? 2 : 3;
        String[] blocks = new String[blocksToCheck];
        //loop to get every block the player is on top of
        for (int i = 0; i < blocksToCheck; i++) {
            // get the block coordinates. Start at left then go to right stopping at either
            // 2 or 3 depending on if the player is aligned with the tiles.
            int[] regionXY = { (int) Math.floor((x + i + width / 2) / 100),
                    (int) Math.floor((y + height + 0.01) / 100) };
            int[] blockXY = { (int) Math.floor((x + i + width / 2) % 100),
                    (int) Math.floor((y + height + 0.01) % 100) };

            // now check the coordinates to see if the block exists. if it does update block
            String block = "air";
            if (Game.coordsInBounds(regionXY[0], regionXY[1])) {
                block = regions[regionXY[0]][regionXY[1]].getBlocks()[blockXY[0]][blockXY[1]];
            }

            // add to blocks
            blocks[i] = block;
            if (block != "air") {
                isOnBlock = true;
            }
        }
        if (isOnBlock) {
            onGround = true;
        } else {
            onGround = false;
        }
        onBlock = blocks;
    }
}

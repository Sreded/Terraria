import java.util.Map;
import java.util.HashMap;

public class KeyMap {
    private Map<Integer, Boolean> keyStates = new HashMap<Integer, Boolean>();
    private Map<String, Boolean> mouseStates = new HashMap<String, Boolean>();

    public KeyMap() {
        keyStates.put(87, false);
        keyStates.put(65, false);
        keyStates.put(83, false);
        keyStates.put(68, false);
        keyStates.put(32, false);

        mouseStates.put("BUTTON1", false);
        mouseStates.put("BUTTON2", false);
    }

    public void pressKey(int keyCode) {

        keyStates.put(keyCode, true);
    }

    public void releaseKey(int keyCode) {
        keyStates.put(keyCode, false);
    }

    public void pressMouseKey(String keyCode) {
        mouseStates.put(keyCode, true);
    }

    public void releaseMouseKey(String keyCode) {
        mouseStates.put(keyCode, false);
    }

    public Map<Integer, Boolean> getKeyStates() {
        return keyStates;
    }

    public Map<String, Boolean> getMouseStates() {
        return mouseStates;
    }
}

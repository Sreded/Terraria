public class Region {
    private String[][] blocks;
    private BiomeMap biomeMap;
    private int regionX;
    private int regionY;
    private int width;
    private int height;

    private double limit = -0.1;
    private double startThresh = -1;
    private double incRate = 0.05;

    public Region(double[][] noiseCaveGen, double[][] noiseBiomeGen, double[][] noiseHeightMap, int regionX,
            int regionY) {
        // 3600
        width = 100;
        height = 100;

        this.regionX = regionX;
        this.regionY = regionY;

        biomeMap = new BiomeMap(width, height, noiseBiomeGen, regionX, regionY);

        // add 4 for a buffer

        // add a buffer so cellAutomata works seamlessly between regions.

        blocks = randomBlocks(width, height, noiseCaveGen);

        if (regionY == 0) {
            // now make mountains
            blocks = addHills(blocks, noiseHeightMap);
        }
        // now run cellular automata algorithm on it with 8 block neighborhood for
        // smoothing

        //
        blocks = cellAutomata(blocks, 10);

        // blocks = ArrayUtil.extractSubarrayStr(blocks, 1, 1, blocks.length - 1,
        // blocks[0].length - 1);

    }

    private String[][] randomBlocks(int width, int height, double[][] noiseCaveGen) {
        // make perlin noise scaled 15 to 50 for smoothness in caves
        double[][] noise = ArrayUtil.extractSubarrayD(noiseCaveGen, regionX * width, regionY * height,
                regionX * width + width, regionY * height + height);
        // threshold starts at -1 so the surface isn't all porous. The surface is all
        // solid then more values are accepted as open space
        double threshold;
        if (regionY == 0) {
            threshold = startThresh;
        } else {
            threshold = limit;
        }
        String[][] out = new String[noise.length][noise[0].length];
        for (int i = 0; i < noise.length; i++) {

            // decrease the threshold value until it reaches 0. only values above 1 will be
            // acepted at that point
            threshold += threshold < 0.0 ? incRate : limit;
            for (int j = 0; j < noise[0].length; j++) {

                // if the noise value is above the threshold that point is a wall. Otherwise its
                // a floor
                out[j][i] = noise[j][i] > threshold ? "wall" : "air";

            }
        }
        return out;
    }

    private String[][] addHills(String[][] blocks, double[][] noiseHeightMap) {
        // only need a 1d perlin noise because i will use this as a heightmap for a 2d
        // world
        double[][] noise = ArrayUtil.extractSubarrayD(noiseHeightMap, regionX * blocks.length, 0,
                regionX * blocks.length + blocks.length, 1);
        // loop through the values and turn walls into flooe at top of map to make
        // rolling hills
        for (int i = 0; i < blocks.length; i++) {
            for (int j = 0; j < (int) Math.floor((noise[i][0] + 1) * 5); j++) {
                blocks[i][j] = "air";
            }
        }
        return blocks;
    }

    private String[][] cellAutomata(String[][] blocks, int smoothingIter) {
        for (int i = 0; i < smoothingIter; i++) {
            String[][] tempBlocks = blocks;
            for (int j = 0; j < blocks.length; j++) {
                for (int k = 0; k < blocks[0].length; k++) {
                    if (blocks[j][k].equals("wall")) {
                        // if cell is a wall
                        // remains a wall if 4 or more neighboring walls
                        // empty if less
                        int wallCount = 0;
                        if (inBounds(k, j - 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j - 1][k].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k, j + 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j + 1][k].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k - 1, j, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j][k - 1].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k + 1, j, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j][k + 1].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k - 1, j - 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j - 1][k - 1].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k + 1, j - 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j - 1][k + 1].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k - 1, j + 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j + 1][k - 1].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k + 1, j + 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j + 1][k + 1].equals("wall")) {
                            wallCount++;
                        }

                        if (wallCount >= 4) {
                            tempBlocks[j][k] = "wall";
                        } else {
                            tempBlocks[j][k] = "air";
                        }
                    } else {
                        // if a cell is empty
                        // remains empty with 5 or less neighboring walls
                        // otherwise becomes a wall
                        int wallCount = 0;
                        if (inBounds(k, j - 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j - 1][k].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k, j + 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j + 1][k].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k - 1, j, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j][k - 1].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k + 1, j, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j][k + 1].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k - 1, j - 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j - 1][k - 1].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k + 1, j - 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j - 1][k + 1].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k - 1, j + 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j + 1][k - 1].equals("wall")) {
                            wallCount++;
                        }
                        if (inBounds(k + 1, j + 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j + 1][k + 1].equals("wall")) {
                            wallCount++;
                        }

                        if (wallCount <= 5) {
                            tempBlocks[j][k] = "air";
                        } else {
                            tempBlocks[j][k] = "wall";
                        }
                    }
                }
            }
            // assign the batch to blocks
            blocks = tempBlocks;
        }
        return blocks;
    }

    private boolean inBounds(int x, int y, int xMin, int yMin, int xMax, int yMax) {
        boolean out = false;
        if (x >= xMin && x < xMax && y >= yMin && y < yMax) {
            out = true;
        }
        return out;
    }

    public String[][] getBlocks() {
        return this.blocks;
    }

    public void setBlocks(String[][] blocks) {
        this.blocks = blocks;
    }

    public String visualizeBlocks() {

        String out = "";
        for (int i = 0; i < blocks.length; i++) {
            for (int j = 0; j < blocks[0].length; j++) {
                if (blocks[j][i].equals("wall")) {
                    out += "#";
                } else {
                    out += "-";
                }
            }
            out += "\n";
        }

        /*
         * String out = "";
         * for(int i = 0; i < noise.length; i++) {
         * for (int j = 0; j < noise[0].length; j++) {
         * out += Math.round(noise[j][i]*100d)/100d;
         * }
         * out += "\n";
         * }
         */
        return out;
    }
}

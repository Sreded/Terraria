import java.awt.*;

public class GraphicsHandler {
    
    //noise stuff for generating new regions when neccesary
    private double[][] noiseHeightMap;
    private double[][] noiseCaveGen;
    private double[][] noiseBiomeGen;


    // screen stuff
    private int blockCountX = 120;
    private int blockCountY = 68;

    // these are half - a certain number to account for the player during rendering
    // and stuff
    private int blocksXHalf = blockCountX / 2 - 1;
    private int blocksYHalf = blockCountY / 2 - 2;

    private int screenX;
    private int screenY;
    private int blockSize;

    private int horizontalPadding;
    private int verticalPadding;

    public GraphicsHandler(double[][] noiseCaveGen, double[][] noiseBiomeGen, double[][] noiseHeightMap) {
        this.noiseCaveGen = noiseCaveGen;
        this.noiseBiomeGen = noiseBiomeGen;
        this.noiseHeightMap = noiseHeightMap;
    }

    /**
     * finds appropriate game viewport dimensions for the given frame
     * */
    public void setViewPort(Frame frame) {
        // Get the frame size
        Dimension frameSize = frame.getSize();
        // get inset dimensions
        Insets insets = frame.getInsets();
        screenX = (int) frameSize.getWidth() - insets.left - insets.right;
        screenY = (int) frameSize.getHeight() - insets.top - insets.bottom;

        int blockX = (int) Math.floor(screenX / blockCountX);
        int blockY = (int) Math.floor(screenY / blockCountY);
        blockSize = blockX < blockY ? blockX : blockY;

        horizontalPadding = (int) (screenX - blockCountX * blockSize) / 2;
        verticalPadding = (int) (screenY - blockCountY * blockSize) / 2;
    }

    public void drawBlocks(Graphics2D g, Player player, Region[][] regions) {
        // player position
        double x = player.getX();
        double y = player.getY();

        // add an extra to render in both directions to never not render a part of
        // screen
        for (int i = 0; i < blockCountX + 1; i++) {
            for (int j = 0; j < blockCountY + 2; j++) {

                // get x and y in region (multiples of 100)
                // starting from left side of screen for point then moving right and down as i
                // and j increase.
                // Finds region that point i j is in relative to the player
                int[] regionXY = Game.getRegionXY(x - blocksXHalf + i, y - blocksYHalf + j);
                int regionX = regionXY[0];
                int regionY = regionXY[1];

                String block;

                // make sure regionX and regionY are in bounds
                if (Game.coordsInBounds(regionX, regionY)) {

                    // make sure that region exists
                    if (regions[regionX][regionY] == null) {
                        regions[regionX][regionY] = new Region(noiseCaveGen, noiseBiomeGen, noiseHeightMap, regionX,
                                regionY);
                    }
                    // block is found almost the same way as region location, just not divided by
                    // 100.
                    int[] blockXY = Game.getBlockXY(x - blocksXHalf + i, y - blocksYHalf + j);
                    int blockX = blockXY[0];
                    int blockY = blockXY[1];

                    block = regions[regionX][regionY].getBlocks()[blockX][blockY];
                } else {
                    block = "air";
                }

                // paint the block
                g.setColor(new Color(139, 69, 19));

                if (block.equals("wall")) {
                    // to get the fractional part of the coordinates in pixels below calculation for
                    // first fractional part then multiplied by block size

                    int blockFractionX = (int) Math.round(((x - Math.floor(x)) * blockSize));
                    int blockFractionY = (int) Math.round(((y - Math.floor(y)) * blockSize));

                    // get the part of x in the region (%100) then subtract by (int) Math.floor(x %
                    // 1 * blockSize) to get that fraction of a block offset. same for y
                    g.fillRect(i * blockSize - blockFractionX + horizontalPadding,
                            j * blockSize - blockFractionY + verticalPadding, blockSize,
                            blockSize);
                }
            }
        }

    }

    /**
     * 
     * @param g the graphics context
     * @return nothing
     */
    public void drawPadding(Graphics2D g) {
        g.setColor(Color.BLACK);
        // left padding
        g.fillRect(0, 0, horizontalPadding, screenY);
        // right padding
        g.fillRect(screenX - horizontalPadding, 0, horizontalPadding, screenY);
        // top padding
        g.fillRect(0, 0, screenX, verticalPadding);
        // bottom padding
        g.fillRect(0, screenY - verticalPadding, screenX, verticalPadding);
    }

    public void drawPlayer(Graphics2D g, Player player) {
        // maybe some item stuff later but just player for now

        g.setColor(Color.BLACK);

        g.fillRect(blocksXHalf * blockSize + horizontalPadding,
                blocksYHalf * blockSize + verticalPadding, blockSize * player.getWidth(),
                blockSize * player.getHeight());
    }

}

import java.util.Arrays;

public class ArrayUtil {
    public static double[][] extractSubarrayD(double[][] arr, int xStart, int yStart, int xEnd, int yEnd) {
        int width = xEnd - xStart;
        int height = yEnd - yStart;

        double[][] subarray = new double[width][height];
        for (int i = 0; i < width; i++) {
            subarray[i] = Arrays.copyOfRange(arr[i + xStart], yStart, yEnd);

        }
        return subarray;
    }

    public static String[][] extractSubarrayStr(String[][] arr, int xStart, int yStart, int xEnd, int yEnd) {
        int width = xEnd - xStart;
        int height = yEnd - yStart;

        String[][] subarray = new String[width][height];
        for (int i = 0; i < width; i++) {
            subarray[i] = Arrays.copyOfRange(arr[i + xStart], yStart, yEnd);

        }
        return subarray;
    }
}

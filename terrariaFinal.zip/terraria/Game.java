import java.awt.*;
import java.awt.event.*;
import java.awt.font.NumericShaper.Range;
import java.awt.image.BufferedImage;

import javax.swing.*;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

public class Game extends JFrame {
    // generation stuff
    // test seed 9232993285l
    private static PerlinNoise perlin = new PerlinNoise(new Random().nextLong());

    private static double[][] noiseHeightMap = perlin.generateNoise(8400, 1, 50, 10);
    private static double[][] noiseCaveGen = perlin.generateNoise(8400, 2400, 60, 40);
    private static double[][] noiseBiomeGen = perlin.generateNoise(8400, 2400, 150, 300);

    // world stuff
    private static ImageLoader imgLoader = new ImageLoader();
    private static Player player = new Player(4800, 85, 2, 3, 150, 10, imgLoader.getImages().get("playerSprites.png"),
            imgLoader.getImages().get("GOLD_AXE.png"));

    // holds the chunks so i dont have to load everything at once
    private static Region[][] regions = new Region[84][24];

    // graphics handler
    private static GraphicsHandler graphics = new GraphicsHandler(noiseCaveGen, noiseBiomeGen, noiseHeightMap,
            imgLoader);
    // threadpool
    private static ThreadPool threadPool = new ThreadPool(20);

    // io stuff
    private static KeyMap keymap = new KeyMap();

    // delta time stuff
    private static long previousTime;
    // steps per frame
    private static int stepsPerFrame = 50;

    // gravity
    private static double GRAVITY = 40;
    private static double TERMINAL_VELOCITY = 100;

    // particles
    private static HashSet<Particle> particles = new HashSet<>();

    public static void main(String[] args) {

        // initialize frame and block sizes and the like

        JFrame frame = new JFrame("Terraria Spinoff");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1920, 1000);

        //scale the game to fit the frame size. 
        graphics.setViewPort(frame);

        // make and add panel
        JPanel panel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2D = (Graphics2D) g;
                // draw background
                graphics.drawBackGround(g2D, player, imgLoader.getImages().get("skyBG.png"),
                        imgLoader.getImages().get("groundBG.png"), null);
                // drawPadding after drawBlocks to mask the unstraightened edges
                graphics.drawBlocks(g2D, player, regions);
                graphics.drawParticles(g2D, particles, player);
                graphics.drawPlayer(g2D, player, imgLoader);
                // RENDER CREATURES
                // get regions to render creatures for
                BoundingBox boundingBox = player.getBoundingBox();

                HashSet<Region> regionsSet = new HashSet<>();
                // Define the multipliers for each corner: top-left, top-right, bottom-left,
                // bottom-right
                //doing this to spot check which regions need their creatures rendered.
                int[][] multipliers = {
                        { -1, -1 }, // top-left
                        { 1, -1 }, // top-right
                        { -1, 1 }, // bottom-left
                        { 1, 1 }, // bottom-right
                        { 0, 0 }, // player position
                        { 0, 1 }, // below player
                        { 0, -1 }, // above player

                };

                // Loop through each multiplier and get the regions. Doing this to spot check
                // which regions are nearby
                for (int[] multiplier : multipliers) {
                    int[] regionXY = getRegionXY(
                            boundingBox.getX() + multiplier[0] * (graphics.getBlockCountX() / 2),
                            boundingBox.getY() + multiplier[1] * (graphics.getBlockCountY() / 2));
                    if (coordsInBounds(regionXY[0], regionXY[1])) {
                        if (regions[regionXY[0]][regionXY[1]] == null) {
                            regions[regionXY[0]][regionXY[1]] = new Region(noiseCaveGen, noiseBiomeGen, noiseHeightMap,
                                    regionXY[0], regionXY[1]);
                        }
                        //add a region to be added
                        regionsSet.add(regions[regionXY[0]][regionXY[1]]);
                    }
                }

                // now loop through and render each creature after converting hashset to
                // arraylist
                //iterate through the regions
                ArrayList<Region> regionsArr = new ArrayList<>(regionsSet);
                for (int i = 0; i < regionsArr.size(); i++) {
                    Region region = regionsArr.get(i);
                    ArrayList<Creature> creatures = new ArrayList<>(region.getCreatureRegion().getCreatures());
                    //draw each creature in this region
                    for (int j = 0; j < region.getCreatureRegion().getCreatures().size(); j++) {
                        graphics.drawCreature(g2D, player, creatures.get(j));
                    }
                }

                //now draw padding and health
                graphics.drawPadding(g2D);
                graphics.drawHealth(g2D, player);

            }
        };
        frame.add(panel);
        // give user instructions.
        JOptionPane.showMessageDialog(frame,
                "Here are Instructions: \nUse 'W' to jump. Use 'A' and 'D' to move left and right. If you die, press 'R' to respawn. \nLeft click the mouse in order to attack enemies.\nDon't get hit. If your health drops to zero you die. \nYou also have a 1 in 10 chance to gain 50 life on getting a kill, and a heart will appear when this happens.\nHave fun!");
        panel.setFocusable(true); // Make sure the panel is focusable
        panel.requestFocusInWindow(); // Request focus for key events
        panel.setDoubleBuffered(true);

        frame.setVisible(true);
        // listens for resize and redraws on resize
        frame.addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                graphics.setViewPort(frame);
                frame.repaint(); // Repaint the frame when it is resized
            }
        });

        // keyevent listener
        panel.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                // detect keypress
                int keyCode = e.getKeyCode();
                keymap.pressKey(keyCode);

                if (keyCode == 82) {
                    // r was pressed
                    if (player.isDead()) {
                        player = new Player(4800, 85, 2, 3, 150, 10, imgLoader.getImages().get("playerSprites.png"),
                                imgLoader.getImages().get("GOLD_AXE.png"));
                    }
                }
            }

            public void keyReleased(KeyEvent e) {
                // detect keypress
                int keyCode = e.getKeyCode();
                keymap.releaseKey(keyCode);
            }

            public void keyTyped(KeyEvent e) {
            };
        });
        startTimer(panel);

        // mousevent listener
        panel.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // no code, just have to make an implementation

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                // no code, just have to make an implementation

            }

            @Override
            public void mouseExited(MouseEvent e) {
                // no code, just have to make an implementation

            }

            @Override
            public void mousePressed(MouseEvent e) {
                player.initiateAttack(e, graphics);

            }

            @Override
            public void mouseReleased(MouseEvent e) {
                player.stopAttack();

            }
        });

        panel.addMouseMotionListener(new MouseMotionListener() {

            @Override
            public void mouseDragged(MouseEvent e) {
                // update the mouseRight on player
                player.updateMouseRight(e, graphics);
            }

            @Override
            public void mouseMoved(MouseEvent e) {
                // update the mouseRight on player
                player.updateMouseRight(e, graphics);
            }

        });

    }

    private static void startTimer(JPanel panel) {
        Timer timer = new Timer(8, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (!player.isDead()) {
                    // attempt to spawn demoneyes
                    attemptSpawn(player, regions);

                    // calculate change in time dt from current time - previous time to get time
                    // between frames.
                    // use this number to determine how far the player moved.
                    double dt = (System.nanoTime() - previousTime) / 1_000_000_000.0f;

                    // update player's frame
                    player.addToIncrement(dt * 20 * (Math.abs(player.getMomentumX()) + 1), dt * 20);
                    // update player's immunity
                    player.subtractImmunityCounter(16 * dt);
                    updateParticleGravity(dt);

                    // do steps so no tunneling
                    for (int i = 0; i < stepsPerFrame; i++) {

                        double multiplier = dt / stepsPerFrame;
                        updatePlayer(multiplier);
                        updateCreatures(multiplier);
                        updateParticles(multiplier);
                        updateParticles(multiplier);

                    }
                }
                // repaint
                panel.repaint();
                previousTime = System.nanoTime();
            }
        });

        // initialize timer
        previousTime = System.nanoTime();
        timer.start();
    }

    /**
     * 
     * @param x in blocks
     * @param y in blocks
     * @return region x, y
     */
    public static int[] getRegionXY(double x, double y) {
        int[] out = new int[2];
        out[0] = (int) Math.floor((x) / 100);
        out[1] = (int) Math.floor((y) / 100);
        return out;
    }

    /**
     * 
     * @param x in blocks
     * @param y in blocks
     * @return block index in region
     */
    public static int[] getBlockXY(double x, double y) {
        int[] out = new int[2];
        out[0] = (int) Math.floor((x) % 100);
        out[1] = (int) Math.floor((y) % 100);
        return out;
    }

    /**
     * checks if a region is in bounds. Uses region coordinates, not block
     * coordinates
     * @param x x in regions
     * @param y y in regions
     */
    public static boolean coordsInBounds(int x, int y) {
        boolean out = false;
        if (x >= 0 && y >= 0 && x < regions.length && y < regions[0].length) {
            out = true;
        }
        return out;
    }

    public static double getFriction(Player player) {
        double out = 0;
        if (player.isOnGround()) {
            Region.Blocks[] blocks = player.getBlocksBelow();
            for (int i = 0; i < blocks.length; i++) {
                // all blocks will have a friction value of 40, in the air it will be 20
                out = 40 > out ? 40 : out;
            }
        } else {
            out = 20 > out ? 20 : out;
        }

        return out;
    }

    /**applies a given friction to a momentum
     * @param momentum momentum to move towards 0
     * @param friction friction to apply
     */
    public static double applyFriction(double momentum, double friction) {
        double out = 0;
        // if its 0 don't change the momentum. Friction works until 0
        if (momentum != 0) {
            if (momentum < 0) {
                // momentum is negative. Add friction. If its greater than 0 after adding then
                // instead make it 0;
                double newMomentum = momentum + friction;
                out = newMomentum < 0 ? newMomentum : 0;
            } else {
                // momentum is positive. subtract friction, then if less than 0 set to 0 instead
                double newMomentum = momentum - friction;
                out = newMomentum > 0 ? newMomentum : 0;
            }
        }
        return out;
    }


    /**
     * attempts to spawn demonEye enemies
     * @param player the player
     * @param regions regions 
     */
    public static void attemptSpawn(Player player, Region[][] regions) {
        Random rand = new Random();
        int num = rand.nextInt(30);
        if (num == 0) {
            BoundingBox boundingBox = player.getBoundingBox();
            double x = boundingBox.getX();
            double y = boundingBox.getY();

            int halfBlockCountX = graphics.getBlockCountX() / 2;
            int halfBlockCountY = graphics.getBlockCountY() / 2;

            // range to spawn in. 20 blocks more than blocks in view in all directions.
            int minX = x - halfBlockCountX - 20 >= 0 ? (int) x - halfBlockCountX - 20 : 0;
            int minY = y - halfBlockCountY - 20 >= 0 ? (int) y - halfBlockCountY - 20 : 0;

            int maxX = x + halfBlockCountX + 20 >= 0 ? (int) x + halfBlockCountX + 20 : 0;
            int maxY = y + halfBlockCountY + 20 >= 0 ? (int) y + halfBlockCountY + 20 : 0;

            // find the region at coordinates just outside of player's field of view
            List<int[]> validSpawns = new ArrayList<>();

            for (int i = minX; i < maxX; i++) {
                for (int j = minY; j < maxY; j++) {
                    // make sure the tile is out of viewing range for player

                    if ((i < x - halfBlockCountX || i > x + halfBlockCountX) || (j < y - halfBlockCountY
                            || j > y + halfBlockCountY)) {

                        Region.Blocks[] blocks = new Region.Blocks[2];

                        // setup blocks
                        int[] blockXY = getBlockXY(i, j);
                        int[] regionXY = getRegionXY(i, j);
                        //check coordinates are in bounds
                        if (coordsInBounds(regionXY[0], regionXY[1])) {
                            //get the region. If it deson't exist (null) then generate one in its place
                            Region region = regions[regionXY[0]][regionXY[1]];
                            if (region == null) {
                                regions[regionXY[0]][regionXY[1]] = new Region(noiseCaveGen, noiseBiomeGen,
                                        noiseHeightMap,
                                        regionXY[0], regionXY[1]);
                                region = regions[regionXY[0]][regionXY[1]];
                            }
                            //get the block coordinates in the region
                            blocks[0] = region.getBlocks()[blockXY[0]][blockXY[1]];

                            //shift blocks to the block to the right
                            blockXY = getBlockXY(i + 1, j);
                            regionXY = getRegionXY(i + 1, j);
                            // same as above
                            if (coordsInBounds(regionXY[0], regionXY[1])) {
                                region = regions[regionXY[0]][regionXY[1]];
                                if (region == null) {
                                    regions[regionXY[0]][regionXY[1]] = new Region(noiseCaveGen, noiseBiomeGen,
                                            noiseHeightMap,
                                            regionXY[0], regionXY[1]);
                                    region = regions[regionXY[0]][regionXY[1]];
                                }
                                blocks[1] = region.getBlocks()[blockXY[0]][blockXY[1]];

                                // if that space is empty then it is a valid spawn. Else dont add
                                if (blocks[0] == Region.Blocks.AIR && blocks[1] == Region.Blocks.AIR) {
                                    validSpawns.add(new int[] { i, j });
                                }
                            }
                        }
                    }
                }
            }
            // pick a random valid spawn and spawn it there
            if (validSpawns.size() > 0) {

                int[] validSpawn = validSpawns.get(rand.nextInt(validSpawns.size()));

                // spawn the creature in its region
                int[] regionXY = getRegionXY(validSpawn[0], validSpawn[1]);
                regions[regionXY[0]][regionXY[1]].creatures.addCreature(
                        new DemonEye(20, 10, validSpawn[0], validSpawn[1], imgLoader.getImages().get("demonEye1.png")));
            }
        }
    }

    public static double applyGravity(double momentum, double gravity) {
        double out = momentum;

        // add gravity to momentum
        double changedMomentum = momentum + gravity;
        // check that new momentum is less than terminal velocity. If not set to the
        // limit.

        out = changedMomentum < TERMINAL_VELOCITY ? changedMomentum : TERMINAL_VELOCITY;
        return out;

    }

    public static void updatePlayer(double multiplier) {
        Map<Integer, Boolean> keyStates = keymap.getKeyStates();
        // movement logic based on key states

        // update player's onBlock

        player.updateOnBlock(regions);

        // update momentum

        // first apply friction. This will only affect x momentum.
        player.setMomentumX(applyFriction(player.getMomentumX(), getFriction(player) * multiplier));
        // then apply gravity
        if (!player.isOnGround()) {
            player.setMomentumY(applyGravity(player.getMomentumY(), GRAVITY * multiplier));
        } else {
            // player.setMomentumY(0);
        }

        // now change momentum based on keystates
        if (keyStates.get(87)) { // 'W' key (keycode 87)
            if (player.isOnGround()) {
                player.setMomentumY(-23); // Move up
            }
        }
        if (keyStates.get(65)) { // 'A' key (keycode 65)
            player.setMomentumX(player.getMomentumX() - player.getSpeed() * multiplier); // Move left
            // flip character
            player.setFlippedSprite(true);
        }
        if (keyStates.get(68)) { // 'D' key (keycode 68)
            player.setMomentumX(player.getMomentumX() + player.getSpeed() * multiplier); // Move right
            // flip character
            player.setFlippedSprite(false);
        }

        double newX;
        double newY;
        // actual move. done in x and y separately to allow for sliding
        // use the bounding box to avoid unupdated player x values
        BoundingBox boundingBox = player.getBoundingBox();

        newX = boundingBox.getBBx() + player.getMomentumX() * multiplier;
        newY = boundingBox.getBBy() + player.getMomentumY() * multiplier;

        // check against blocks
        double[] newXY = CollisionUtil.attemptMove(newX, newY, boundingBox.getBBwidth(),
                boundingBox.getBBheight(), regions, noiseCaveGen, noiseBiomeGen, noiseHeightMap);

        // check against creatures. Since creatures are update after player, consider
        // their future positions. This will be done in the function
        newXY = CollisionUtil.attemptMoveAgainstCreatures(newXY[0], newXY[1], regions, player);
        // reset momentum on collision
        if (newXY[0] != newX) {
            // if there was a collision then reset the players momentum. Same for y
            player.setMomentumX(0);
        }
        if (newXY[1] != newY) {
            player.setMomentumY(0);
        }

        boundingBox.setBBx(newXY[0]);
        boundingBox.setBBy(newXY[1]);

    }

    public static void updateCreatures(double multiplier) {
        BoundingBox boundingBox = player.getBoundingBox();
        int[] regionXY = getRegionXY(boundingBox.getX(), boundingBox.getY());
        if (coordsInBounds(regionXY[0], regionXY[1])) {
            // 5x5 block of regions to iterate thriuh and update creatures in. They are
            // centered on the player
            for (int i = -2; i < 3; i++) {
                for (int j = -2; j < 3; j++) {
                    if (coordsInBounds(regionXY[0] + i, regionXY[1] + j)) {
                        Region region = regions[regionXY[0] + i][regionXY[1] + j];
                        if (region != null) {
                            // delete dead creatures
                            region.getCreatureRegion().purgeDead();
                            ArrayList<Creature> creatures = new ArrayList<Creature>(
                                    region.getCreatureRegion().getCreatures());
                            for (int k = 0; k < creatures.size(); k++) {
                                Creature creature = creatures.get(k);
                                if (creature instanceof DemonEye) {
                                    // its a demoneye
                                    DemonEye demonEye = (DemonEye) creature;
                                    // update movement
                                    demonEye.targetPlayer(player);

                                    // calculate new position
                                    double newX = demonEye.getBoundingBox().getBBx()
                                            + demonEye.getMomentumX() * multiplier;
                                    double newY = demonEye.getBoundingBox().getBBy()
                                            + demonEye.getMomentumY() * multiplier;

                                    // check new position against blocks
                                    double[] newXY = CollisionUtil.attemptMove(newX, newY,
                                            demonEye.getBoundingBox().getBBwidth(),
                                            demonEye.getBoundingBox().getBBheight(), regions, noiseCaveGen,
                                            noiseBiomeGen, noiseHeightMap);
                                    // check position against player
                                    double[] XY = newXY;
                                    newXY = CollisionUtil.attemptMoveAgainstPlayer(newXY[0], newXY[1], demonEye,
                                            player);
                                    // set position
                                    demonEye.getBoundingBox().setBBx(newXY[0]);
                                    demonEye.getBoundingBox().setBBy(newXY[1]);
                                    if (!Arrays.equals(newXY, XY) && player.getImmunityCounter() == 0) {
                                        // hurt the player
                                        player.setHealth(player.getHealth() - demonEye.getDamage());
                                        player.resetImmunityIncrement();
                                        player.setMomentumX(Math.signum(demonEye.getMomentumX()) * 10);
                                        player.setMomentumY(5);
                                    }

                                    int[] demonEyeRXY = getRegionXY(boundingBox.getX(), boundingBox.getY());

                                    // remove and readd just in case. (for region posirttion)
                                    region.getCreatureRegion().removeCreature(demonEye);
                                    regions[demonEyeRXY[0]][demonEyeRXY[1]].getCreatureRegion()
                                            .addCreature(demonEye);

                                    // subtract from immunity counter
                                    demonEye.subtractImmunityCounter(16 * multiplier);

                                    // apply bounce if neccessary

                                    // for the check with weapon get the Side enum resupt
                                    CollidingBlock.Sides side = CollisionUtil.isCreatureCollidingWithWeapon(newXY[0],
                                            newXY[1], demonEye,
                                            player);

                                    if (newXY[0] != newX && newXY[1] != newY) {
                                        // bounce on both x and y axises
                                        demonEye.bounce(0);
                                    }
                                    // check that the player is swinging, and has a weapon in hand to check the
                                    // weapon collision

                                    else if (player.isSwinging() && player.getHeldItem() instanceof Weapon
                                            && demonEye.getImmunityCounter() == 0
                                            && side != CollidingBlock.Sides.NONE) {
                                        // on top of bounce also apply damage to demonEye because it collided with the
                                        // weapon
                                        Weapon weapon = (Weapon) player.getHeldItem();

                                        demonEye.setHealth(demonEye.getHealth() - weapon.getDamage());
                                        if (demonEye.isDead()) {
                                            // is dead - make particles
                                            BufferedImage image = imgLoader.getImages().get("eyeCorpse1.png");

                                            double aspectRatio = (double) image.getWidth() / image.getHeight();
                                            double sizeMultiplier = 0.75;

                                            // generate two particles that are the eye corpse
                                            Particle particle = new Particle(3000, threadPool, image, "no", 1.0,
                                                    Math.random() * Math.PI * 2,
                                                    false,
                                                    demonEye.getBoundingBox().getX(), demonEye.getBoundingBox().getY(),
                                                    demonEye.getBoundingBox().getHeight() * sizeMultiplier,
                                                    demonEye.getBoundingBox().getHeight() / aspectRatio
                                                            * sizeMultiplier,
                                                    Particle.Display.IMAGE, Math.random() * 10 - 5, -20);

                                            image = imgLoader.getImages().get("eyeCorpse2.png");

                                            Particle particle2 = new Particle(3000, threadPool, image, "no", 1.0,
                                                    Math.random() * Math.PI * 2,
                                                    false,
                                                    demonEye.getBoundingBox().getX(), demonEye.getBoundingBox().getY(),
                                                    demonEye.getBoundingBox().getHeight() * sizeMultiplier,
                                                    demonEye.getBoundingBox().getHeight() / aspectRatio
                                                            * sizeMultiplier,
                                                    Particle.Display.IMAGE, Math.random() * 10 - 5, -20);
                                                    //make them slowly fade out
                                            particle.fadeOut(0.01, 100);
                                            particle2.fadeOut(0.01, 100);
                                            //add them to the particles list
                                            particles.add(particle);
                                            particles.add(particle2);

                                            // 1 in 10 chance to heal for 100hp
                                            if (Math.floor(Math.random() * 10) == 0) {
                                                player.setHealth(player.getHealth() + 50);
                                                // make heart particle
                                                image = imgLoader.getImages().get("heart.png");

                                                double width = image.getWidth() * graphics.getBlockSize() / 100;
                                                double height = image.getHeight() * graphics.getBlockSize() / 100;

                                                particle = new Particle(2000, threadPool, image, "none", 1.0, 0, true,
                                                        demonEye.getBoundingBox().getX() - width / 2,
                                                        demonEye.getBoundingBox().getY() - height / 2, width, height,
                                                        Particle.Display.IMAGE, 0, -5);

                                                // add and fade
                                                particle.fadeOut(0.05, 100);
                                                particles.add(particle);
                                            }

                                        }
                                        // reset immunity after getting hit
                                        demonEye.resetImmunityIncrement();

                                        // now bounce
                                        demonEye.bounce(
                                                side == CollidingBlock.Sides.LEFT || side == CollidingBlock.Sides.RIGHT
                                                        ? 1
                                                        : 2);
                                    } else if (newXY[0] != newX) {
                                        // this means a bounce on the x axis
                                        demonEye.bounce(1);
                                    } else if (newXY[1] != newY) {
                                        // bounce on y axis
                                        demonEye.bounce(2);
                                    }

                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public static void updateParticles(double dt) {
        // get rid of particles where time is up
        ArrayList<Particle> deleteObjs = new ArrayList<>();
        for (Particle particle : particles) {
            if (particle.getCountDownMS() <= 0) {
                deleteObjs.add(particle);
            } else {
                if (!particle.isNoClip()) {
                    // interacts with world
                    particle.setMomentumX(particle.getMomentumX() - dt / 100);
                    double newX = particle.getX() + particle.getMomentumX() * dt;
                    double newY = particle.getY() + particle.getMomentumY() * dt;
                    double[] newXY = CollisionUtil.attemptMove(newX, newY, particle.getWidth(), particle.getHeight(),
                            regions, noiseCaveGen, noiseBiomeGen, noiseHeightMap);
                    // if it hits the ground friction will stop it
                    if (newXY[1] != newY) {
                        particle.setMomentumX(0);
                    }
                    // update location
                    particle.setX(newXY[0]);
                    particle.setY(newXY[1]);
                } else {
                    particle.setMomentumX(applyFriction(particle.getMomentumX(), 40));
                    particle.setX(particle.getX() + particle.getMomentumX() * dt);

                    // particle.setMomentumY(particle.getMomentumX() + dt * GRAVITY);
                    particle.setY(particle.getY() + particle.getMomentumY() * dt);
                }
            }

        }
        // now delete all the particles that are out of time

        for (Particle particle : deleteObjs) {
            particles.remove(particle);
        }
    }

    public static void updateParticleGravity(double dt) {
        for (Particle particle : particles) {
            if (!particle.isNoClip()) {
                particle.setMomentumY(particle.getMomentumY() + GRAVITY * dt);
            }
        }
    }
}

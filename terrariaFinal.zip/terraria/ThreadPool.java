import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadPool {
    private ExecutorService executor;

    public ThreadPool(int threadCount) {
        this.executor = Executors.newFixedThreadPool(threadCount);
    }

    public void submit(Runnable task) {
        executor.submit(task);
    }

    
}

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class CollisionUtil {
    /**
     * checks left of x1
     * 
     * @param x1
     * @param w1
     * @param x2
     * @param w2
     * @return
     */

    public static boolean isCollidingRect(double x1, double y1, double w1, double h1, double x2, double y2, double w2,
            double h2) {
        boolean out = false;
        if (x1 + w1 > x2 && x1 < x2 + w2
                && y1 + h1 > y2 && y1 < y2 + h2) {
            out = true;
        }
        return out;
    }

    /**
     * gets the side of the collision in a simple rectangular collision. The side is
     * relative to rect 1
     * 
     * @return and enum with one of the sides
     */
    public static CollidingBlock.Sides rectCollisionGetSide(double x1, double y1, double w1, double h1, double x2,
            double y2, double w2,
            double h2) {
        CollidingBlock.Sides side;
        // get dists between respecitve sides
        double offsetX = Math.min(x1 + w1 - x2, x2 + w2 - x1);
        double offsetY = Math.min(y1 + h1 - y2, y2 + h2 - y1);

        if (offsetX <= offsetY) {
            if (x1 + w1 / 2 <= x2 + w2 / 2) {
                side = CollidingBlock.Sides.RIGHT;
            } else {
                side = CollidingBlock.Sides.LEFT;
            }
        } else {
            if (y1 + h1 / 2 <= y2 + h2 / 2) {
                side = CollidingBlock.Sides.BOTTOM;
            } else {
                side = CollidingBlock.Sides.TOP;
            }
        }
        return side;

    }

    /**
     * 
     * @param w1 must be positive
     * @param h1 must be positive
     * @returns CollisionData with all the stats. CollisionData.getSides() will
     *          contain side from block's perspective
     */

    public static boolean isCollidingLineLine(double x1, double y1, double x2, double y2, double x3, double y3,
            double x4, double y4) {
        boolean out = false;
        // get slopes
        double m1 = x2 - x1 == 0 ? Double.POSITIVE_INFINITY : (y2 - y1) / (x2 - x1);
        double m2 = x4 - x3 == 0 ? Double.POSITIVE_INFINITY : (y4 - y3) / (x4 - x3);
        // y = mx + b
        // given y and x and m
        // b = y-mx
        if (m1 == m2 && y1 - m1 * x1 == y3 - m2 * x3) {
            // lines identical

            // make sure they overlap
            if (Math.max(x1, x2) >= Math.min(x3, x4) && Math.min(x1, x2) <= Math.max(x3, x4) &&
                    Math.max(y1, y2) >= Math.min(y3, y4) && Math.min(y1, y2) <= Math.max(y3, y4)) {
                out = true;
            }
        } else {
            // i don't understand determinants for matrixes, so the math is beyond me here.
            // Do need to still make sure not dividing by 0
            double denominator = (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);
            if (denominator != 0) {
                // calculate the distance to intersection point
                double uA = ((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3))
                        / denominator;
                double uB = ((x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3))
                        / denominator;

                // if uA and uB are between 0-1, lines are colliding. (Because it is parameter
                // for parametric equations)
                if (uA >= 0 && uA <= 1 && uB >= 0 && uB <= 1) {

                    out = true;
                }
            }
        }
        return out;
    }

    public static boolean isCollidingLineSquare(double[] p1, double[] p2, double x1, double y1, double w1,
            double h1) {

        boolean collision = false;

        // first do a quick check to see if the line is completely inside the box. If it
        // is, then don't do the second part since there weren't any intersections.
        if ((p1[0] >= x1 && p1[0] <= x1 + w1 && p1[1] >= y1 && p1[1] <= y1 + h1)
                || (p2[0] >= x1 && p2[0] <= x1 + w1 && p2[1] >= y1 && p2[1] <= y1 + h1)) {
            collision = true;
        } else {

            // get the sides of the box

            double[][] topLine = { { x1, y1 }, { x1 + w1, y1 } };
            double[][] leftLine = { { x1, y1 }, { x1, y1 + h1 } };
            double[][] bottomLine = { { x1, y1 + h1 }, { x1 + w1, y1 + h1 } };
            double[][] rightLine = { { x1 + w1, y1 }, { x1 + w1, y1 + h1 } };

            double[][][] sides = { topLine, leftLine, bottomLine, rightLine };

            for (int i = 0; i < 4; i++) {
                double[][] line = sides[i];
                if (isCollidingLineLine(p1[0], p1[1], p2[0], p2[1], line[0][0], line[0][1], line[1][0], line[1][1])) {
                    collision = true;
                }
            }
        }
        return collision;

    }

    public static double[] attemptMove(double attemptX, double attemptY, double width, double height,
            Region[][] regions, double[][] noiseCaveGen, double[][] noiseBiomeGen, double[][] noiseHeightMap) {
        double[] out = new double[2];

        // keep track of colliding blocks
        List<CollidingBlock> collidingBlocks = new ArrayList<CollidingBlock>();
        boolean collision = false;
        // check if collision in general viscinity
        for (int i = -5; i < 5; i++) {
            for (int j = -5; j < 5; j++) {
                // get the block
                int[] blockXY = Game.getBlockXY(attemptX + i, attemptY + j);
                int[] regionXY = Game.getRegionXY(attemptX + i, attemptY + j);
                Region.Blocks block = Region.Blocks.AIR;

                if (Game.coordsInBounds(regionXY[0], regionXY[1])) {
                    if (regions[regionXY[0]][regionXY[1]] == null) {
                        regions[regionXY[0]][regionXY[1]] = new Region(noiseCaveGen, noiseBiomeGen, noiseHeightMap,
                                regionXY[0], regionXY[1]);
                    }
                    block = regions[regionXY[0]][regionXY[1]].getBlocks()[blockXY[0]][blockXY[1]];
                }

                if (block != Region.Blocks.AIR && block!= Region.Blocks.DIRTWALL) {
                    if (isCollidingRect(attemptX,
                            attemptY,
                            width,
                            height,
                            blockXY[0] + regionXY[0] * 100, blockXY[1] + regionXY[1] * 100, 1, 1)) {

                        collidingBlocks.add(
                                new CollidingBlock(blockXY[0] + regionXY[0] * 100, blockXY[1] + regionXY[1] * 100));
                        collision = true;
                    }
                }

            }
        }

        if (!collision) {
            out[0] = attemptX;
            out[1] = attemptY;
        } else {
            // loop through each collision and handle
            for (int i = 0; i < collidingBlocks.size(); i++) {
                CollidingBlock collidingBlock = collidingBlocks.get(i);
                // get the side of the collision
                CollidingBlock.Sides side = rectCollisionGetSide(attemptX,
                        attemptY,
                        width,
                        height, collidingBlock.getX(), collidingBlock.getY(), 1, 1);

                // handle the coordinates with the side thing
                if (side == CollidingBlock.Sides.BOTTOM) {
                    out[0] = attemptX;
                    out[1] = collidingBlock.getY() - height - 0.01;

                } else if (side == CollidingBlock.Sides.TOP) {
                    out[0] = attemptX;
                    out[1] = collidingBlock.getY() + 1.01;
                } else if (side == CollidingBlock.Sides.LEFT) {
                    out[0] = collidingBlock.getX() + 1.01;
                    out[1] = attemptY;
                } else {
                    // right side
                    out[0] = collidingBlock.getX() - width - 0.01;
                    out[1] = attemptY;
                }
            }
        }

        return out;

    }

    public static double[] attemptMoveAgainstPlayer(double attemptX, double attemptY, Creature creature,
            Player player) {
        double[] out = new double[2];
        // check for collisions with player.
        BoundingBox boundingBoxPlayer = player.getBoundingBox();
        BoundingBox boundingBox = creature.getBoundingBox();
        // check for a collision between player and demon eye
        if (CollisionUtil.isCollidingRect(attemptX, attemptY,
                boundingBox.getBBwidth(), boundingBox.getBBheight(),
                boundingBoxPlayer.getBBx(), boundingBoxPlayer.getBBy(),
                boundingBoxPlayer.getBBwidth(), boundingBoxPlayer.getBBheight())) {
            // find side
            CollidingBlock.Sides side = CollisionUtil.rectCollisionGetSide(
                    attemptX, attemptY,
                    boundingBox.getBBwidth(), boundingBox.getBBheight(),
                    boundingBoxPlayer.getBBx(), boundingBoxPlayer.getBBy(),
                    boundingBoxPlayer.getBBwidth(), boundingBoxPlayer.getBBheight());

            // handle depending on side
            if (side == CollidingBlock.Sides.BOTTOM) {
                out[0] = attemptX;
                out[1] = boundingBoxPlayer.getBBy() - boundingBoxPlayer.getBBheight() - 0.01;

            } else if (side == CollidingBlock.Sides.TOP) {
                out[0] = attemptX;
                out[1] = boundingBoxPlayer.getBBy() + boundingBoxPlayer.getBBheight() + 0.01;
            } else if (side == CollidingBlock.Sides.LEFT) {
                out[0] = boundingBoxPlayer.getBBx() + boundingBoxPlayer.getBBwidth() + 0.01;
                out[1] = attemptY;
            } else {
                // right side
                out[0] = boundingBoxPlayer.getBBx() - boundingBoxPlayer.getBBwidth() - 0.01;
                out[1] = attemptY;
            }
        } else {
            // no collision, return input
            out[0] = attemptX;
            out[1] = attemptY;
        }
        return out;
    }

    /**
     * will return none for enum if no collision. Else will return the enum of the
     * side.
     */
    public static CollidingBlock.Sides isCreatureCollidingWithWeapon(double attemptX, double attemptY,
            Creature creature,
            Player player) {
        CollidingBlock.Sides out = CollidingBlock.Sides.NONE;

        BoundingBox boundingBox = player.getBoundingBox();

        // weapon offsets for x and y. flip x if player is flipped
        // get offsets for player weapon hitbox
        double[] offsets = {
                0.5, -1
        };
        // flip if neccessary
        if (player.getFlippedSprite()) {
            //mouse is on left side, hitbox is flipped
            offsets[0] -= (boundingBox.getBBwidth());
        }

        if (isCollidingRect(attemptX, attemptY, creature.getBoundingBox().getBBwidth(),
                creature.getBoundingBox().getBBheight(), boundingBox.getBBx() + offsets[0],
                boundingBox.getBBy() + offsets[1], boundingBox.getBBwidth() + 1,
                boundingBox.getBBheight() - offsets[1] - 0.5)) {
            // the creature is in the weapon hitbox. Find the side
            CollidingBlock.Sides side = rectCollisionGetSide(attemptX, attemptY, creature.getBoundingBox().getBBwidth(),
                    creature.getBoundingBox().getBBheight(), boundingBox.getBBx() + offsets[0],
                    boundingBox.getBBy() + offsets[1], boundingBox.getBBwidth() + 1,
                    boundingBox.getBBheight() - offsets[1] - 0.5);

            out = side;
        }
        return out;
    }

    /**
     * checks for where the player should go based on obstacles. Assumes a future
     * position for the obstacles
     * 
     * @param attemptX
     * @param attemptY
     * @param regions
     * @param player
     * @return
     */
    public static double[] attemptMoveAgainstCreatures(double attemptX, double attemptY, Region[][] regions,
            Player player) {

        double[] out = new double[2];
        int[] regionXY = Game.getRegionXY(attemptX, attemptY);

        BoundingBox boundingBoxPlayer = player.getBoundingBox();
        for (int i = -1; i < 2; i++) {
            for (int j = -1; j < 2; j++) {
                // if the region exists
                if (Game.coordsInBounds(regionXY[0] + i, regionXY[1] + j)
                        && regions[regionXY[0] + i][regionXY[1] + j] != null) {
                    // get the creatures
                    ArrayList<Creature> creatures = new ArrayList<>(
                            regions[regionXY[0] + i][regionXY[1] + j].getCreatureRegion().getCreatures());
                    if (creatures.size() == 0) {
                        // no creatures, so no collisions

                        out[0] = attemptX;
                        out[1] = attemptY;
                    }
                    for (int k = 0; k < creatures.size(); k++) {
                        Creature creature = creatures.get(k);
                        BoundingBox boundingBox = creature.getBoundingBox();
                        if (CollisionUtil.isCollidingRect(attemptX, attemptY,
                                boundingBoxPlayer.getBBwidth(), boundingBoxPlayer.getBBheight(),
                                boundingBox.getBBx(),
                                boundingBox.getBBy(),
                                boundingBox.getBBwidth(), boundingBox.getBBheight())) {
                            // find side
                            CollidingBlock.Sides side = CollisionUtil.rectCollisionGetSide(
                                    attemptX, attemptY,
                                    boundingBoxPlayer.getBBwidth(), boundingBoxPlayer.getBBheight(),
                                    boundingBox.getBBx(),
                                    boundingBox.getBBy(),
                                    boundingBox.getBBwidth(), boundingBox.getBBheight());

                            // handle depending on side
                            if (side == CollidingBlock.Sides.BOTTOM) {
                                out[0] = attemptX;
                                out[1] = boundingBox.getBBy() - boundingBox.getBBheight()
                                        - 0.01;

                            } else if (side == CollidingBlock.Sides.TOP) {
                                out[0] = attemptX;
                                out[1] = boundingBox.getBBy() + boundingBox.getBBheight()
                                        + 0.01;
                            } else if (side == CollidingBlock.Sides.LEFT) {
                                out[0] = boundingBox.getBBx() + boundingBox.getBBwidth()
                                        + 0.01;
                                out[1] = attemptY;
                            } else {
                                // right side
                                out[0] = boundingBox.getBBx() - boundingBox.getBBwidth()
                                        - 0.01;
                                out[1] = attemptY;
                            }

                        } else {
                            // no collision, return input
                            out[0] = attemptX;
                            out[1] = attemptY;
                        }
                    }
                }

            }
        }

        return out;

    }
}

// container class for collidingBlocks
class CollidingBlock {
    private int x;
    private int y;
    private CollidingBlock.Sides side;
    private double[][] line;
    private  Corners corner;

    public enum  Sides {
        LEFT,
        RIGHT,
        TOP,
        BOTTOM,
        NONE
    }

    public enum Corners {
        TL,
        BR,
        BL,
        TR
    }

    public CollidingBlock(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /**
     * gets the top left corner
     * 
     * @param a
     * @param b
     * @return
     */
    // public static int compareTL(CollidingBlock a, CollidingBlock b) {
    // int out = 0;
    // if (a.getX() > b.getX()) {
    // out = 1;
    // } else if (a.getT() < b.getT()) {
    // out = -1;
    // }
    // return out;
    // }

    // getter for 'line'
    public double[][] getLine() {
        return line;
    }

    // Getter for 'x'
    public int getX() {
        return x;
    }

    // Getter for 'y'
    public int getY() {
        return y;
    }

    // Getter for 't'
    public Corners getCorner() {
        return corner;
    }

    // Getter for 'side'
    public CollidingBlock.Sides getSide() {
        return side;
    }

}

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.Timer;

public class Particle {
    public enum Display {
        IMAGE,
        STRING
    }

    private BufferedImage image;
    private String text;
    private double alpha;
    private double rotation;
    private boolean noClip;

    // positioning and size
    private double x;
    private double y;
    private double width;
    private double height;

    private double scale;
    private double countDownMS;

    private ThreadPool threadPool;

    private Display display;
    private double momentumX;
    private double momentumY;

    public Particle(double timeMS, ThreadPool threadPool, BufferedImage image, String text, double alpha,
            double rotation,
            boolean noClip, double x, double y,
            double width, double height, Particle.Display display, double momentumX, double momentumY) {
        this.image = image;
        this.text = text;
        this.alpha = alpha;
        this.rotation = rotation;
        this.noClip = noClip;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.display = display;
        this.countDownMS = timeMS;
        this.scale = 1;
        this.threadPool = threadPool;
        this.momentumX = momentumX;
        this.momentumY = momentumY;

        Runnable task = new Runnable() {
           @Override
           public void run() {
                Timer timer = new Timer(100, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        countDownMS -= 100;
                        if (countDownMS <= 0) {
                            Timer timer = (Timer) e.getSource();
                            timer.stop();
                        }

                    }
                });
                timer.start();
           }
       };

       threadPool.submit(task);

    }

    /**
     * makes the text smaller
     * 
     * @param amount amount to decrease size by over time
     * @param time   interval to decrease by amount
     */
    public void smallify(double amount, int time) {
        Runnable task = new Runnable() {
            @Override
            public void run() {
                // start a timer to decrement
                Timer timer = new Timer(time, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        scale -= amount;
                        if (scale <= 0) {
                            scale = 0;
                            Timer timer = (Timer) e.getSource();
                            timer.stop();
                        }
                    }
                });
                timer.start();
            }
        };

        threadPool.submit(task);
    }

    public void biggify(double amount, int time, double maxScale) {
        Runnable task = new Runnable() {
            @Override
            public void run() {
                // start a timer to decrement
                Timer timer = new Timer(time, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        scale += amount;
                        if (scale >= maxScale) {
                            scale = maxScale;
                            Timer timer = (Timer) e.getSource();
                            timer.stop();
                        }
                    }
                });
                timer.start();
            }
        };

        threadPool.submit(task);
    }

    public void fadeIn(double amount, int time) {
        Runnable task = new Runnable() {
            @Override
            public void run() {
                // start a timer to decrement
                Timer timer = new Timer(time, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        alpha += amount;
                        if (alpha >= 1d) {
                            alpha = 1d;
                            Timer timer = (Timer) e.getSource();
                            timer.stop();
                        }
                    }
                });
                timer.start();
            }
        };

        threadPool.submit(task);
    }

    public void fadeOut(double amount, int time) {
        Runnable task = new Runnable() {
            @Override
           public void run() {
                // start a timer to decrement
                Timer timer = new Timer(time, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        alpha -= amount;
                        if (alpha <= 0) {
                            alpha = 0;
                            Timer timer = (Timer) e.getSource();
                            timer.stop();
                        }
                    }
                });
                timer.start();
           }
       };

        //threadPool.submit(task);
    }

    /** make bigger by amount at interval time */
    // public void biggify(double amount, double time)

    public BufferedImage getImage() {
        return image;
    }

    public void setImage(BufferedImage image) {
        this.image = image;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public double getAlpha() {
        return alpha;
    }

    public void setAlpha(int alpha) {
        this.alpha = alpha;
    }

    public Display getDisplay() {
        return display;
    }

    public void setDisplay(Display display) {
        this.display = display;
    }

    public double getRotation() {
        return rotation;
    }

    public boolean isNoClip() {
        return noClip;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    public double getCountDownMS() {
        return countDownMS;
    }

    public double getMomentumX() {
        return momentumX;
    }
    public void setMomentumX(double momentumX) {
        this.momentumX = momentumX;
    }
    public double getMomentumY() {
        return momentumY;
    }
    public void setMomentumY(double momentumY) {
        this.momentumY = momentumY <= 100 ? momentumY : this.momentumY;
    }

    public void setX(double x) {
        this.x = x;
    }
    public void setY(double y) {
        this.y = y;
    }

}
import java.awt.image.BufferedImage;

public class Weapon extends Item {
    private int damage;

    public Weapon(Item.Types type, BufferedImage image, int damage) {
        super(type, image);
        this.damage = damage;
    }

    public int getDamage() {
        return damage;
    }
}

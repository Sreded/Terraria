import java.awt.image.BufferedImage;

public class Item {
    public enum Types {
        GOLD_AXE
    }

    private Types type;
    private BufferedImage image;

    public Item(Types type, BufferedImage image) {
        this.type = type;
        this.image = image;
    }

    public Types getType() {
        return type;
    }

    public BufferedImage getImage() {
        return image;
    }
}

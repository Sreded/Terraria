public class BoundingBox {

    private double x;
    private double y;
    private double width;
    private double height;

    // width height x y of bounding box
    private double BBwidth;
    private double BBheight;
    private double BBx;
    private double BBy;

    public BoundingBox(double x, double y, double width, double height) {

        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.BBwidth = (double) width;
        this.BBheight = (double) height;
        this.BBx = x;
        this.BBy = y;

    }

    public double getBBheight() {
        return BBheight;
    }

    public double getBBwidth() {
        return BBwidth;
    }

    public double getHeight() {
        return height;
    }

    public double getWidth() {
        return width;
    }

    public double getBBx() {
        return BBx;
    }

    public void setBBx(double x) {
        // new-old to get movement
        double diff = x - this.BBx;
        this.BBx = x;
        this.x += diff;
    }

    public double getBBy() {
        return BBy;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setBBy(double y) {
        // new-old to get movement
        double diff = y - this.BBy;
        this.BBy = y;
        this.y += diff;
    }

    /**
     * rotates around center
     * 
     * @param degree
     */
    public void rotateTo(double degree) {

        double cx = x + width / 2;
        double cy = y + height / 2;

        double minX;
        double maxX;
        double minY;
        double maxY;

        // array with each point
        double[][] points = {
                { x, y },
                { x + width, y },
                { x, y + height },
                { x + width, y + height }
        };

        double[][] rotatedPoints = new double[4][2];
        for (int i = 0; i < points.length; i++) {

            // x' = cx + (x - cx) * cos(θ) - (y - cy) * sin(θ)
            double newX = cx + (points[i][0] - cx) * Math.cos(degree) - (points[i][1] - cy) * Math.sin(degree);

            // y' = cy + (x - cx) * sin(θ) + (y - cy) * cos(θ)
            double newY = cy + (points[i][0] - cx) * Math.sin(degree) + (points[i][1] - cy) * Math.cos(degree);

            rotatedPoints[i][0] = newX;
            rotatedPoints[i][1] = newY;
        }

        minX = Math.min(Math.min(rotatedPoints[0][0], rotatedPoints[1][0]),
                Math.min(rotatedPoints[2][0], rotatedPoints[3][0]));
        minY = Math.min(Math.min(rotatedPoints[0][1], rotatedPoints[1][1]),
                Math.min(rotatedPoints[2][1], rotatedPoints[3][1]));
        maxX = Math.max(Math.max(rotatedPoints[0][0], rotatedPoints[1][0]),
                Math.max(rotatedPoints[2][0], rotatedPoints[3][0]));
        maxY = Math.max(Math.max(rotatedPoints[0][1], rotatedPoints[1][1]),
                Math.max(rotatedPoints[2][1], rotatedPoints[3][1]));

        BBwidth = maxX - minX;
        BBheight = maxY - minY;
        BBx = minX;
        BBy = minY;
    }
}

import java.awt.image.BufferedImage;

public class DemonEye extends Creature {

    private double nochangeMultiplier = 1;

    public DemonEye(int health, int damage, double x, double y, BufferedImage image) {
        super(health, damage, x, y, 1.6, 1, true, image);
    }

    public void targetPlayer(Player player) {
        // target player
        BoundingBox boundingBoxPlayer = player.getBoundingBox();
        BoundingBox boundingBoxDemonEye = super.getBoundingBox();

        double rotation = super.getRotation();

        // use tan functino so i dont have to calculate hypotenuse
        // tanh(opposite/adjacent) or y/x
        double rotationFacePlayer = Math.atan2((boundingBoxPlayer.getBBy() - boundingBoxDemonEye.getBBy()),
                (boundingBoxPlayer.getBBx() - boundingBoxDemonEye.getBBx()));

        // dk why but if x is negative it needs to be flipped

        // clock wise angle from endAngle - startAngle. If negative add 2PI (eg -1 would
        // be 359 (in degrees))
        double clockwiseAngle = rotationFacePlayer - rotation;
        clockwiseAngle = clockwiseAngle >= 0 ? clockwiseAngle : clockwiseAngle + 2 * Math.PI;

        double counterClockwiseAngle = 2 * Math.PI - clockwiseAngle;

        // calculate how close it was in degrees
        double rotationScore = clockwiseAngle < counterClockwiseAngle ? clockwiseAngle : counterClockwiseAngle;

        // calculate distance to player (used so it doesn't just stay at the player)
        double playerDist = Math.sqrt(Math.pow(boundingBoxPlayer.getBBx() - boundingBoxDemonEye.getBBx(), 2)
                + Math.pow(boundingBoxPlayer.getBBy() - boundingBoxDemonEye.getBBy(), 2));

        // rotate towards player by score keeping distance to player in mind

        if (clockwiseAngle <= counterClockwiseAngle) {
            // rotate clockwise (because its shortest rotation to get there)
            rotation += rotationScore / 100 * sigmoid(playerDist, 12, 0.5) * nochangeMultiplier;
        } else {
            rotation -= rotationScore / 100 * sigmoid(playerDist, 12, 0.5) * nochangeMultiplier;
        }

        super.setRotation(rotation);

        // get the momentum for x and y using unit circle
        double momentumX = Math.cos(rotation);
        double momentumY = Math.sin(rotation);
        // add a sigmoid for player distance to make sure it continues momentum through
        // attack
        double speedMultiplier = 1 / sigmoid(playerDist, 10, 0.5);
        double rotationMultiplier = 1 / sigmoid(rotationScore, Math.PI, 0.5);
        // add speed cap
        speedMultiplier = speedMultiplier < 3 ? speedMultiplier : 3;

        // sigmoid there to make sure the demon eyes don't get outran by player
        momentumX *= rotationMultiplier * speedMultiplier * (sigmoid(playerDist, 30, 1) + 1) * 2;
        momentumY *= rotationMultiplier * speedMultiplier * (sigmoid(playerDist, 30, 1) + 1) * 2;

        super.setMomentumX(momentumX);
        super.setMomentumY(momentumY);

        nochangeMultiplier = 0.00001 + nochangeMultiplier < 1 ? 0.00001 + nochangeMultiplier : 1;
    }

    /**
     * bounces the eye given which axis(es) its colliding with
     * 
     * @param axis 0: x and y; 1: x; 2: y;
     */
    public void bounce(int axis) {
        // just inverting rotations from momentum to bounce (over x or y axis)

        double[] momentum = { super.getMomentumX(), super.getMomentumY() };

        if (axis == 0) {
            // both x and y
            momentum[0] = -momentum[0];
            momentum[1] = -momentum[1];
        } else if (axis == 1) {
            // just x
            momentum[0] = -momentum[0];
        } else {
            // just y
            momentum[1] = -momentum[1];
        }
        double rotation = Math.atan2(momentum[1], momentum[0]);
        super.setRotation(rotation);
        super.setMomentumX(super.getMomentumX() < 15 ? super.getMomentumX() * 20 : super.getMomentumX());
        super.setMomentumX(super.getMomentumY() < 15 ? super.getMomentumY() * 20 : super.getMomentumY());
        nochangeMultiplier = 0.00001;
    }

    private double sigmoid(double num, double shift, double sharpness) {
        return 1 / (1 + Math.pow(Math.E, -sharpness * (num - shift)));
    }

}

import java.util.HashSet;
import java.util.Iterator;

public class Region {
    public enum Blocks {
        AIR,
        GRASS,
        DIRT,
        STONE,
        STONEWALL,
        DIRTWALL
    }

    private Blocks[][] blocks;
    private BiomeMap biomeMap;
    // positioning and size
    private int regionX;
    private int regionY;
    private int width = 100;
    private int height = 100;

    // creatures
    CreatureRegion creatures = new CreatureRegion();
    // generation params
    private double limit = -0.1;
    private double startThresh = -1;
    private double incRate = 0.05;

    public Region(double[][] noiseCaveGen, double[][] noiseBiomeGen, double[][] noiseHeightMap, int regionX,
            int regionY) {

        this.regionX = regionX;
        this.regionY = regionY;

        biomeMap = new BiomeMap(width, height, noiseBiomeGen, regionX, regionY);

        blocks = randomBlocks(width, height, noiseCaveGen);
        if(regionY >= 1) {
            blocks = cellAutomata(blocks, 10);
        }

        if (regionY == 1) {
            // now make mountains
            blocks = addHills(blocks, noiseHeightMap);
        }
        // now run cellular automata algorithm on it with 8 block neighborhood for
        // smoothing

        

    }

    private Blocks[][] randomBlocks(int width, int height, double[][] noiseCaveGen) {
        // make perlin noise scaled 15 to 50 for smoothness in caves
        double[][] noise = ArrayUtil.extractSubarrayD(noiseCaveGen, regionX * width, regionY * height,
                regionX * width + width, regionY * height + height);
        // threshold starts at -1 so the surface isn't all porous. The surface is all
        // solid then more values are accepted as open space
        double threshold;
        if (regionY == 0) {
            threshold = Double.POSITIVE_INFINITY;
        } else if (regionY == 1) {
            threshold = startThresh;
        } else {
            threshold = limit;
        }
        Blocks[][] out = new Blocks[noise.length][noise[0].length];
        for (int i = 0; i < noise.length; i++) {

            // decrease the threshold value until it reaches 0. only values above 1 will be
            // acepted at that point
            threshold += threshold < 0.0 ? incRate : limit;
            for (int j = 0; j < noise[0].length; j++) {

                // if the noise value is above the threshold that point is a wall. Otherwise its
                // a dirtwall. Dirtwalls above the ground will be turned to sky later.

                // if regionY == 0 then set to air
                if (regionY == 0) {
                    out[j][i] = Blocks.AIR;
                } else {
                    out[j][i] = noise[j][i] > threshold ? Blocks.DIRT : Blocks.DIRTWALL;
                }
            }
        }
        return out;
    }

    private Blocks[][] addHills(Blocks[][] blocks, double[][] noiseHeightMap) {
        // only need a 1d perlin noise because i will use this as a heightmap for a 2d
        // world
        double[][] noise = ArrayUtil.extractSubarrayD(noiseHeightMap, regionX * blocks.length, 0,
                regionX * blocks.length + blocks.length, 1);
        // loop through the values and turn walls into flooe at top of map to make
        // rolling hills
        for (int i = 0; i < blocks.length; i++) {
            // get a floored value (because its an index) of the noise shifted up by 1 to
            // get ridof negatives then multiplied by 5 for bigger hills
            int limit = (int) Math.floor((noise[i][0] + 1) * 5) + 1;
            for (int j = 0; j < limit; j++) {
                if (j == limit - 1) {
                    // check that block below is dirtwall. If it is it will cover a cave unless we
                    // dont place it
                    if (blocks[i][j + 1] != Blocks.DIRTWALL) {
                        blocks[i][j] = Blocks.GRASS;
                    }

                } else {
                    blocks[i][j] = Blocks.AIR;
                }
            }
        }
        return blocks;
    }

    private Blocks[][] cellAutomata(Blocks[][] blocks, int smoothingIter) {
       
        for (int i = 0; i < smoothingIter; i++) {
            Blocks[][] tempBlocks = blocks;
            for (int j = 0; j < blocks.length; j++) {
                for (int k = 0; k < blocks[0].length; k++) {
                    if (blocks[j][k] != Blocks.AIR && blocks[j][k] != Blocks.DIRTWALL) {
                        // if cell is a wall
                        // remains a wall if 4 or more neighboring walls
                        // empty if less
                        int wallCount = 0;
                        // if it isnt air, its a block
                        if (inBounds(k, j - 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j - 1][k] != Blocks.AIR && blocks[j-1][k] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k, j + 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j + 1][k] != Blocks.AIR && blocks[j+1][k] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k - 1, j, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j][k - 1] != Blocks.AIR && blocks[j][k-1] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k + 1, j, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j][k + 1] != Blocks.AIR && blocks[j][k+1] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k - 1, j - 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j - 1][k - 1] != Blocks.AIR && blocks[j-1][k-1] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k + 1, j - 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j - 1][k + 1] != Blocks.AIR && blocks[j-1][k+1] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k - 1, j + 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j + 1][k - 1] != Blocks.AIR && blocks[j+1][k-1] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k + 1, j + 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j + 1][k + 1] != Blocks.AIR && blocks[j+1][k+1] != Blocks.DIRTWALL) {
                            wallCount++;
                        }

                        if (wallCount >= 4) {
                            tempBlocks[j][k] = blocks[j][k];
                        } else {
                            
                                //in dirtwall region
                                tempBlocks[j][k] = Blocks.DIRTWALL;
                            
                        }
                    } else {
                        // if a cell is empty
                        // remains empty with 5 or less neighboring walls
                        // otherwise becomes a wall
                        int wallCount = 0;
                        
                        if (inBounds(k, j - 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j - 1][k] != Blocks.AIR && blocks[j-1][k] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k, j + 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j + 1][k] != Blocks.AIR && blocks[j+1][k] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k - 1, j, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j][k - 1] != Blocks.AIR && blocks[j][k-1] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k + 1, j, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j][k + 1] != Blocks.AIR && blocks[j][k+1] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k - 1, j - 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j - 1][k - 1] != Blocks.AIR && blocks[j-1][k-1] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k + 1, j - 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j - 1][k + 1] != Blocks.AIR && blocks[j-1][k+1] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k - 1, j + 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j + 1][k - 1] != Blocks.AIR && blocks[j+1][k-1] != Blocks.DIRTWALL) {
                            wallCount++;
                        }
                        if (inBounds(k + 1, j + 1, 0, 0, blocks.length, blocks[0].length)
                                && blocks[j + 1][k + 1] != Blocks.AIR && blocks[j+1][k+1] != Blocks.DIRTWALL) {
                            wallCount++;
                        }

                        if (wallCount <= 5) {
                            
                                // its not.
                                tempBlocks[j][k] = Blocks.DIRTWALL;
                            
                        } else {
                            tempBlocks[j][k] = blocks[j][k];
                        }
                    }
                }
            }
            // assign the batch to blocks
            blocks = tempBlocks;
        }
        return blocks;
    }

    private boolean inBounds(int x, int y, int xMin, int yMin, int xMax, int yMax) {
        boolean out = false;
        if (x >= xMin && x < xMax && y >= yMin && y < yMax) {
            out = true;
        }
        return out;
    }

    public Blocks[][] getBlocks() {
        return this.blocks;
    }

    public void setBlocks(Blocks[][] blocks) {
        this.blocks = blocks;
    }

    public CreatureRegion getCreatureRegion() {
        return creatures;
    }

    public String visualizeBlocks() {

        String out = "";
        for (int i = 0; i < blocks.length; i++) {
            for (int j = 0; j < blocks[0].length; j++) {
                if (blocks[j][i].equals(Blocks.DIRT)) {
                    out += "#";
                } else {
                    out += "-";
                }
            }
            out += "\n";
        }
        return out;
    }

}

class CreatureRegion {
    private HashSet<Creature> creatures = new HashSet<>();
    private int spawnCap = 10;

    public void addCreature(Creature creature) {
        if (creatures.size() < spawnCap) {
            creatures.add(creature);
        }
    }

    public void removeCreature(Creature creature) {
        creatures.remove(creature);
    }

    /**
     * removes any dead creatures in the list
     */
    public void purgeDead() {
        // get iterator from hashset
        HashSet<Creature> newCreatures = new HashSet<>();
        Iterator<Creature> iter = creatures.iterator();
        // go through and add each to the new hashset. At the end set creatures to
        // newcreatures.
        while (iter.hasNext()) {
            Creature creature = iter.next();
            if (!creature.isDead()) {
                newCreatures.add(creature);
            }
        }
        this.creatures = newCreatures;
    }

    // getter for creature list
    public HashSet<Creature> getCreatures() {
        return creatures;
    }
}

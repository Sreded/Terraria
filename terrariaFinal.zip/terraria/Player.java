import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.nio.Buffer;
import java.util.Arrays;

public class Player extends Creature {

    // for controls and acceleration
    private float speed;
    private float maxSpeed;

    private boolean onGround = false;
    private Region.Blocks[] onBlock = { Region.Blocks.AIR };

    private BufferedImage[] swingingImages;
    private BufferedImage standingImage;
    private BufferedImage[] walkingImages;
    private BufferedImage fallingImage;

    private boolean isSwinging = false;
    // keep track of which side the mouse is on for the swing
    private boolean mouseRight = true;

    private boolean isWalking = false;
    private boolean isFalling = false;

    private double walkingIncrement = 0;
    private double swingingIncrement = 0;

    private boolean isFlippedSprite = false;

    // for what item player is holding
    private Item heldItem;

    // for swinging motion
    private double armRotation = Math.PI / 3;
    private int swingingFrame = 0;

    public Player(double x, double y, int width, int height, int health, int damage, BufferedImage playerImages,
            BufferedImage weaponImage) {
        super(health, damage, x, y, width, height, false, null);
        BufferedImage image = playerImages.getSubimage(0, 0, 40, 48);
        standingImage = image;
        super.setImage(standingImage);

        speed = 80;
        maxSpeed = 15;

        heldItem = new Weapon(Item.Types.GOLD_AXE, weaponImage, 10);

        // get swinging frames. First frame starts at y 56 on the spritesheet. then
        // sprites are 48 px tall with 8 px buffer after
        // there are 4 frames
        swingingImages = new BufferedImage[4];
        for (int i = 0; i < 4; i++) {
            // + 56 includes frame and 8px buffer. all frames are 40px wide
            swingingImages[i] = playerImages.getSubimage(0, 56 + i * 56, 40, 48);
        }

        // get falling frame
        fallingImage = playerImages.getSubimage(0, 280, 40, 48);

        // get walking frames. There are 14 of them. Same pattern as the swinging images
        walkingImages = new BufferedImage[14];
        for (int i = 0; i < 14; i++) {
            // starts at 336
            walkingImages[i] = playerImages.getSubimage(0, 336 + 56 * i, 40, 48);
        }

    }

    public boolean isMouseRight() {
        return mouseRight;
    }

    public boolean isSwinging() {
        return isSwinging;
    }

    public void initiateAttack(MouseEvent e, GraphicsHandler graphics) {
        isSwinging = true;
        armRotation = Math.PI / 3;
        swingingIncrement = 0;

        // update mouseRight
        updateMouseRight(e, graphics);

    }

    public void updateMouseRight(MouseEvent e, GraphicsHandler graphics) {
        // get center of the screen, which is where the center of the player is
        double cx = (graphics.getBlockCountX()) * graphics.getBlockSize() / 2 + graphics.getHorizontalPadding();

        // if mouse is left of it, store that. else store right

        mouseRight = e.getX() < cx ? false : true;
    }

    public void stopAttack() {
        isSwinging = false;
    }

    public double getArmRotation() {
        return armRotation;
    }

    public Item getHeldItem() {
        return heldItem;
    }

    public int getSwingingFrame() {
        return swingingFrame;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }

    public float getSpeed() {
        return speed;
    }

    public float getMaxSpeed() {
        return maxSpeed;
    }

    @Override
    public void setMomentumX(double momentum) {
        if (momentum >= 0) {
            super.setMomentumX(momentum > maxSpeed ? maxSpeed : momentum);
        } else {
            super.setMomentumX(momentum < -maxSpeed ? -maxSpeed : momentum);
        }
        if (super.getMomentumX() == 0) {
            isWalking = false;
        } else {
            isWalking = true;
        }
    }

    @Override
    public void setMomentumY(double momentum) {
        super.setMomentumY(momentum);
        if (momentum < -10 || momentum > 10) {
            isFalling = true;
            // dont set the false here that way you stay falling in jumps
        }
    }

    public boolean isOnGround() {
        return onGround;
    }

    /**
     * returns which block the player is above. Whichever is closest to player
     */
    public Region.Blocks[] getBlocksBelow() {
        return onBlock;
    }

    public void updateOnBlock(Region[][] regions) {

        boolean isOnBlock = false;
        // check if the player is on a coordinate exactly (eg 5.00). if it is, only need
        // to check 2 blocks beneath. Otherwise have to check 3
        int blocksToCheck = super.getBoundingBox().getBBx() % 1 == 0 ? 2 : 3;

        Region.Blocks[] blocks = new Region.Blocks[blocksToCheck];
        // loop to get every block the player is on top of
        for (int i = 0; i < blocksToCheck; i++) {
            // get the block coordinates. Start at left then go to right stopping at either
            // 2 or 3 depending on if the player is aligned with the tiles.

            // bounding box's x then for y use bounding box's y and add the height to get to
            // the bottom tiles

            int[] regionXY = Game.getRegionXY((super.getBoundingBox().getBBx() + i),
                    (super.getBoundingBox().getBBy() + getBoundingBox().getBBheight()
                            + 0.01));
            int[] blockXY = Game.getBlockXY((super.getBoundingBox().getBBx() + i),
                    (super.getBoundingBox().getBBy() + super.getBoundingBox().getBBheight() + 0.01));

            // now check the coordinates to see if the block exists. if it does update block
            Region.Blocks block = Region.Blocks.AIR;
            if (Game.coordsInBounds(regionXY[0], regionXY[1])) {
                block = regions[regionXY[0]][regionXY[1]].getBlocks()[blockXY[0]][blockXY[1]];
            }

            // add to blocks
            blocks[i] = block;
            if (block != Region.Blocks.AIR && block != Region.Blocks.DIRTWALL) {
                isOnBlock = true;
            }
        }
        if (isOnBlock) {
            onGround = true;
            isFalling = false;
        } else {
            onGround = false;
        }
        onBlock = blocks;
    }

    public void setFlippedSprite(boolean isFlippedSprite) {
        this.isFlippedSprite = isFlippedSprite;
    }

    public boolean getFlippedSprite() {
        return isFlippedSprite;
    }

    /**
     * adds to two increments that controls which frame the animation should be on.
     * 
     * @param walkingAmount the amount to add to the total. Limit is 100.
     */
    public void addToIncrement(double walkingAmount, double swingingAmount) {
        double limitWalking = 100;
        double limitSwinging = 10;

        // for swinging animation have to set rotation to 0 if over limit
        if (swingingAmount + swingingIncrement > limitSwinging) {
            armRotation = Math.PI / 3;
        }

        // add amount to frame increment. If it goes past limit, subtract limit from the
        // total.
        this.walkingIncrement = walkingIncrement + walkingAmount < limitWalking ? walkingAmount + walkingIncrement
                : (walkingAmount + walkingIncrement) - limitWalking;
        this.swingingIncrement = swingingIncrement + swingingAmount < limitSwinging ? swingingAmount + swingingIncrement
                : (swingingAmount + swingingIncrement) - limitSwinging;

        if (isFalling) {
            super.setImage(fallingImage);
        } else if (isWalking) {

            double dividedLimit = limitWalking / walkingImages.length;

            for (int i = 1; i <= walkingImages.length; i++) {
                // start i at 1 so we never say is less than 0
                if (dividedLimit * i >= walkingIncrement) {
                    super.setImage(walkingImages[i - 1]);
                    break;
                }
            }

        } else {

            super.setImage(standingImage);
        }
        // paste top half of swinging animation on player
        if (isSwinging) {
            double limitQuarter = limitSwinging / swingingImages.length;
            for (int i = 1; i <= swingingImages.length; i++) {
                // start i at 1 so we never say is less than 0
                if (limitQuarter * i >= swingingIncrement) {
                    // the subimage width is 40 (width of image) and height of 34 (extends down to
                    // belt of player in image)
                    super.setImage(spliceImages(super.getImage(), swingingImages[i - 1]));
                    swingingFrame = i - 1;
                    break;
                }
            }
            // scale the swingingIncrement to radians
            armRotation -= swingingAmount / 3.5;
        }

    }

    /**
     * helper functon for addToINcrement. Used to splice two images together. Less
     * general purpose, prmarily used for putting swinging top on.
     * 
     * @param baseImage the base image.
     * @param topImage  the image to be pased to the top left corner of the first
     *                  image
     * @return resulting BufferedImage
     */
    private BufferedImage spliceImages(BufferedImage baseImage, BufferedImage originalTopImage) {
        // make new image to store result. Use ARGB to handle transparent pixels
        BufferedImage outImage = new BufferedImage(baseImage.getWidth(), baseImage.getHeight(),
                BufferedImage.TYPE_INT_ARGB);
        // copy originalTopImage in order to avoid editing the object passed in
        BufferedImage topImage = new BufferedImage(originalTopImage.getWidth(), originalTopImage.getHeight(),
                BufferedImage.TYPE_INT_ARGB);

        // get graphics
        Graphics2D g = (Graphics2D) outImage.getGraphics();
        Graphics2D gTop = (Graphics2D) topImage.getGraphics();

        // paste originalTopImage onto copy
        gTop.drawImage(originalTopImage, 0, 0, null);

        // make the graphics also handle transparent pixels
        g.setComposite(AlphaComposite.Src);
        gTop.setComposite(AlphaComposite.Src);

        // draw base on
        g.drawImage(baseImage, 0, 0, null);

        // set the top part to alpha so it doesn't interfere (like jumping arms will be
        // erased). Will go down to waistline.
        // doing waistline because that is the end of the pasted region this functino is
        // intended for - swinging

        g.setColor(new Color(0, 0, 0, 0));
        gTop.setColor(new Color(0, 0, 0, 0));
        // set to belt if walking or jumping (so the bottom of those shines through).
        // Otherwise don't for standing
        if (isWalking || isFalling) {
            g.fillRect(0, 0, 40, 34);
            // now delete part directly below belt - excluding the sides
            // only do so if player is walking or falling. Will keep it to overwrite
            gTop.fillRect(12, 35, 16, 14);
            // and get rid of rest of feet artifacts. Doing so to avoid chopping off hand.
            gTop.fillRect(28, 45, 2, 4);

        } else {
            // if standing we don't want any of the normal texture. it will leave artifacts
            // otherwise
            g.fillRect(0, 0, 40, 48);
        }

        g.setComposite(AlphaComposite.SrcOver);
        //
        // draw top image on

        g.drawImage(topImage, 0, 0, null);
        g.dispose();
        gTop.dispose();
        return outImage;

    }
}

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import java.util.HashMap;

public class ImageLoader {
    private HashMap<String, BufferedImage> images = new HashMap<>();

    public ImageLoader() {
        loadFolder("textures");
        loadFolder("fonts");
    }

    public HashMap<String, BufferedImage> getImages() {
        return images;
    }

    private void loadFolder(String folderPath) {
        File folder = new File(folderPath);

        if (folder.exists()) {
            if (folder.listFiles().length > 0) {
                File[] files = folder.listFiles();
                for (int i = 0; i < files.length; i++) {
                    File file = files[i];

                    try {
                        images.put(file.getName(), ImageIO.read(file));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        }
    }
}

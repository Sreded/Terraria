import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Observer;

import javax.xml.crypto.dsig.Transform;

public class GraphicsHandler {

    // noise stuff for generating new regions when neccesary
    private double[][] noiseHeightMap;
    private double[][] noiseCaveGen;
    private double[][] noiseBiomeGen;

    // screen stuff
    private int blockCountX = 120;
    private int blockCountY = 68;

    // these are half - a certain number to account for the player during rendering
    // and stuff
    private int blocksXHalf = blockCountX / 2 - 1;
    private int blocksYHalf = blockCountY / 2 - 2;

    private int screenX;
    private int screenY;
    private int blockSize;

    private int horizontalPadding;
    private int verticalPadding;

    private Font pixel;

    private ImageLoader imgLoader;

    public GraphicsHandler(double[][] noiseCaveGen, double[][] noiseBiomeGen, double[][] noiseHeightMap,
            ImageLoader imgLoader) {
        this.noiseCaveGen = noiseCaveGen;
        this.noiseBiomeGen = noiseBiomeGen;
        this.noiseHeightMap = noiseHeightMap;
        this.imgLoader = imgLoader;

    }

    public int getVerticalPadding() {
        return verticalPadding;
    }

    public int getHorizontalPadding() {
        return horizontalPadding;
    }

    public int getBlockSize() {
        return blockSize;
    }

    public int getBlockCountX() {
        return blockCountX;
    }

    public int getBlockCountY() {
        return blockCountY;
    }

    /**
     * finds appropriate game viewport dimensions for the given frame
     */
    public void setViewPort(Frame frame) {
        // Get the frame size
        Dimension frameSize = frame.getSize();
        // get inset dimensions
        Insets insets = frame.getInsets();
        screenX = (int) frameSize.getWidth() - insets.left - insets.right;
        screenY = (int) frameSize.getHeight() - insets.top - insets.bottom;

        int blockX = (int) Math.floor(screenX / blockCountX);
        int blockY = (int) Math.floor(screenY / blockCountY);
        blockSize = blockX < blockY ? blockX : blockY;

        horizontalPadding = (int) (screenX - blockCountX * blockSize) / 2;
        verticalPadding = (int) (screenY - blockCountY * blockSize) / 2;
    }

    public void drawBlocks(Graphics2D g, Player player, Region[][] regions) {
        // player position
        double x = player.getBoundingBox().getBBx();
        double y = player.getBoundingBox().getBBy();

        // add an extra to render in both directions to never not render a part of
        // screen
        for (int i = 0; i < blockCountX + 1; i++) {
            for (int j = 0; j < blockCountY + 2; j++) {

                // get x and y in region (multiples of 100)
                // starting from left side of screen for point then moving right and down as i
                // and j increase.
                // Finds region that point i j is in relative to the player
                int[] regionXY = Game.getRegionXY(x - blocksXHalf + i, y - blocksYHalf + j);
                int regionX = regionXY[0];
                int regionY = regionXY[1];

                Region.Blocks block;

                // make sure regionX and regionY are in bounds
                if (Game.coordsInBounds(regionX, regionY)) {

                    // make sure that region exists
                    if (regions[regionX][regionY] == null) {
                        regions[regionX][regionY] = new Region(noiseCaveGen, noiseBiomeGen, noiseHeightMap, regionX,
                                regionY);
                    }
                    // block is found almost the same way as region location, just not divided by
                    // 100.
                    int[] blockXY = Game.getBlockXY(x - blocksXHalf + i, y - blocksYHalf + j);
                    int blockX = blockXY[0];
                    int blockY = blockXY[1];

                    block = regions[regionX][regionY].getBlocks()[blockX][blockY];
                } else {
                    block = Region.Blocks.AIR;
                }

                // draw the block

                if (block != Region.Blocks.AIR) {
                    BufferedImage image = null;
                    switch (block) {
                        case Region.Blocks.DIRT:
                            image = imgLoader.getImages().get("dirt.png");
                            break;
                        case Region.Blocks.DIRTWALL:
                            image = imgLoader.getImages().get("dirtWall.png");
                            break;
                        case Region.Blocks.GRASS:
                            image = imgLoader.getImages().get("grass.png");
                            break;
                    }
                    // to get the fractional part of the coordinates in pixels below calculation for
                    // first fractional part then multiplied by block size

                    int blockFractionX = (int) Math.round(((x - Math.floor(x)) * blockSize));
                    int blockFractionY = (int) Math.round(((y - Math.floor(y)) * blockSize));

                    // get the part of x in the region (%100) then subtract by (int) Math.floor(x %
                    // 1 * blockSize) to get that fraction of a block offset. same for y
                    g.setComposite(AlphaComposite.SrcOver);
                    g.drawImage(image, i * blockSize - blockFractionX + horizontalPadding,
                            j * blockSize - blockFractionY + verticalPadding, blockSize,
                            blockSize, null);
                }
            }
        }

    }

    /**
     * 
     * @param g the graphics context
     * @return nothing
     */
    public void drawPadding(Graphics2D g) {
        g.setColor(Color.BLACK);
        // left padding
        g.fillRect(0, 0, horizontalPadding, screenY);
        // right padding
        g.fillRect(screenX - horizontalPadding, 0, horizontalPadding, screenY);
        // top padding
        g.fillRect(0, 0, screenX, verticalPadding);
        // bottom padding
        g.fillRect(0, screenY - verticalPadding, screenX, verticalPadding);
    }

    public void drawPlayer(Graphics2D g, Player player, ImageLoader imgLoader) {
        if (!player.isDead()) {
            // maybe some item stuff later but just player for now

            // for transformations with rotations (in case player is rotated)
            g.setColor(Color.BLACK);
            BoundingBox boundingBox = player.getBoundingBox();
            BufferedImage image = player.getImage();
            BufferedImage itemImage = player.getHeldItem().getImage();
            AffineTransform originalTransform = g.getTransform();

            // heights are all the same, so no need to adust. Widths vary so must draw
            // knowning actual size is 24 px
            int width = image.getWidth();

            double scale = boundingBox.getWidth() * blockSize / 24;

            if (player.getFlippedSprite()) {
                // horizontally flip the image for player and item
                BufferedImage flippedImagePlayer = new BufferedImage(image.getWidth(), image.getHeight(),
                        BufferedImage.TYPE_INT_ARGB);
                BufferedImage flippedImageItem = new BufferedImage(itemImage.getWidth(), itemImage.getHeight(),
                        BufferedImage.TYPE_INT_ARGB);

                // get graphic contexts
                Graphics2D playerImgG = (Graphics2D) flippedImagePlayer.getGraphics();
                // set the handling of source pixels
                playerImgG.setComposite(AlphaComposite.Src);
                // transform horizontally
                AffineTransform transform = AffineTransform.getScaleInstance(-1, 1);
                transform.translate(-image.getWidth(), 0);
                playerImgG.drawImage(image, transform, null);
                playerImgG.dispose();
                // set image to flipped
                image = flippedImagePlayer;

                // repeat for item
                Graphics2D itemImgG = (Graphics2D) flippedImageItem.getGraphics();
                // handling of source pixels
                itemImgG.setComposite(AlphaComposite.Src);
                // transform
                transform = AffineTransform.getScaleInstance(-1, 1);
                transform.translate(-itemImage.getWidth(), 0);
                itemImgG.drawImage(itemImage, transform, null);
                itemImgG.dispose();
                itemImage = flippedImageItem;

            }
            double cx = blocksXHalf * blockSize + horizontalPadding
                    + (boundingBox.getBBwidth() / 2) * (double) blockSize;
            double cy = blocksYHalf * blockSize + verticalPadding
                    + (boundingBox.getBBheight() / 2) * (double) blockSize;
            if (player.getRotation() != 0) {

                g.translate(cx, cy);
                g.rotate(player.getRotation());
                g.translate(-cx, -cy);
                // draw
                g.drawImage(image, (int) (cx - boundingBox.getWidth() / 2 * blockSize),
                        (int) (cy - boundingBox.getHeight() / 2 * blockSize),
                        (int) (blockSize * boundingBox.getWidth()),
                        (int) (blockSize * boundingBox.getHeight()), null);
                g.setTransform(originalTransform);
            } else {
                // draw normally

                // take width and make it so that the scaled image is around the center width
                // wise.
                g.drawImage(image, (int) (cx - width * scale / 2),
                        (int) (cy - boundingBox.getHeight() / 2 * blockSize - 6 * scale),
                        (int) (width * scale),
                        (int) (blockSize * boundingBox.getHeight() + 6 * scale), null);
            }

            // if the player is swinging then draw his held item at correct place
            if (player.isSwinging()) {
                int frame = player.getSwingingFrame();
                // relative locations to center
                double[][] offsets = {
                        { -0.7, -3 },
                        { 0.3, -2.8 },
                        { 0.5, -1.8 },
                        { 0.3, -1.5 }
                };

                int itemWidth = blockSize * 2;
                int itemHeight = itemWidth;

                double itemX = cx + offsets[frame][0] * blockSize * (player.getFlippedSprite() == false ? 1 : -1)
                        + (player.getFlippedSprite() == false ? 0 : -itemWidth);
                double itemY = cy + offsets[frame][1] * blockSize;

                double translateX = 0;
                if (player.getFlippedSprite()) {
                    // if is flipped then rotate from bottom right corner
                    translateX = itemX + itemHeight;
                } else {
                    // else rotate from bottom left
                    translateX = itemX;
                }

                // translate, rotate , translate back, draw image, then reset the rotation so
                // other drawings arent messed up.
                g.translate(translateX, itemY + itemHeight);
                g.rotate(player.getArmRotation() * (player.getFlippedSprite() == false ? -1 : 1));
                g.translate(-translateX, -itemY - itemHeight);
                g.drawImage(itemImage, (int) (itemX), (int) (itemY), itemWidth, itemHeight, null);
                g.setTransform(originalTransform);

            }

        } else {
            // get bounding boc player
            BoundingBox boundingBox = player.getBoundingBox();

            double cx = blocksXHalf * blockSize + horizontalPadding
                    + (boundingBox.getBBwidth() / 2) * (double) blockSize;
            double cy = blocksYHalf * blockSize + verticalPadding
                    + (boundingBox.getBBheight() / 2) * (double) blockSize;

            // draw the death screen if dead
            BufferedImage image = imgLoader.getImages().get("deathScreen.png");

            int width = image.getWidth()  * blockSize /13;
            int height =image.getHeight()  * blockSize/13;
            g.drawImage(image, (int) (cx - width/2),
                    (int) (cy - height/2),
                    (int) (width),
                    (int) (height), null);
        }
    }

    public void drawParticles(Graphics2D g, HashSet<Particle> particles, Player player) {
        for (Particle particle : particles) {
            if (particle.getDisplay() == Particle.Display.IMAGE) {
                // draw its image
                // set alpha
                g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) particle.getAlpha()));

                // get locatino for center of rotation and for drawing
                int screenX = (int) ((particle.getX() - player.getBoundingBox().getBBx() + blocksXHalf) * blockSize
                        + horizontalPadding);
                int screenY = (int) ((particle.getY() - player.getBoundingBox().getBBy() + blocksYHalf) * blockSize
                        + verticalPadding);
                double width = particle.getWidth() * blockSize;
                double height = particle.getHeight() * blockSize;
                AffineTransform originalTransform = g.getTransform();
                // rotate
                g.translate(screenX + (int) (width / 2), screenY + (int) (height / 2));
                g.rotate(particle.getRotation());
                g.translate(-screenX - (int) (width / 2), -screenY - (int) (height / 2));

                // draw
                g.drawImage(particle.getImage(),
                        (int) ((particle.getX() - player.getBoundingBox().getBBx() + blocksXHalf) * blockSize
                                + horizontalPadding),
                        (int) ((particle.getY() - player.getBoundingBox().getBBy() + blocksYHalf) * blockSize
                                + verticalPadding),
                        (int) (particle.getWidth() * blockSize), (int) (particle.getHeight() * blockSize), null);
                // reset rotation and opacity
                g.setComposite(AlphaComposite.SrcOver);
                g.setTransform(originalTransform);
            }
        }
    }

    public void drawCreature(Graphics2D g, Player player, Creature creature) {
        // maybe some item stuff later but just player for now

        g.setColor(Color.BLACK);
        BoundingBox boundingBox = creature.getBoundingBox();
        BufferedImage image = creature.getImage();
        AffineTransform originalTransform = g.getTransform();

        // gets center of creature on screen

        double cx = blocksXHalf * blockSize + horizontalPadding
                - (player.getBoundingBox().getBBx() - boundingBox.getBBx()) * blockSize
                + (boundingBox.getBBwidth() / 2) * (double) blockSize;
        double cy = blocksYHalf * blockSize + verticalPadding
                - (player.getBoundingBox().getBBy() - boundingBox.getBBy()) * blockSize
                + (boundingBox.getBBheight() / 2) * (double) blockSize;
        if (creature.getRotation() != 0) {

            g.translate(cx, cy);
            g.rotate(creature.getRotation());
            g.translate(-cx, -cy);
            // draw
            g.drawImage(image, (int) (cx - boundingBox.getWidth() / 2 * blockSize),
                    (int) (cy - boundingBox.getHeight() / 2 * blockSize), (int) (blockSize * boundingBox.getWidth()),
                    (int) (blockSize * boundingBox.getHeight()), null);
            g.setTransform(originalTransform);
        } else {
            // draw normally
            g.drawImage(image, (int) (cx - boundingBox.getWidth() / 2 * blockSize),
                    (int) (cy - boundingBox.getHeight() / 2 * blockSize), (int) (blockSize * boundingBox.getWidth()),
                    (int) (blockSize * boundingBox.getHeight()), null);
        }
    }

    public void drawHealth(Graphics2D g, Player player) {
        g.setColor(Color.RED);

        File file = new File("fonts/pixel.TTF");
        try {
            pixel = Font.createFont(Font.TRUETYPE_FONT, file).deriveFont((float) blockSize * 2);

        } catch (FontFormatException | IOException e) {
            System.out.println("font load error: " + e);
        }

        g.setFont(pixel);

        g.drawString(player.getHealth() + "/" + player.getMaxHealth(),
                (blockCountX - 12) * blockSize + horizontalPadding,
                blockSize * 2 + verticalPadding);
    }

    public void drawBackGround(Graphics2D g, Player player, BufferedImage topBG, BufferedImage bottomBG,
            BufferedImage cloudBG) {
        double multiplier = blockSize / 20d;
        double offsetXTop = (player.getBoundingBox().getBBx() * 10 + player.getBoundingBox().getBBwidth() / 2)

                % (topBG.getWidth());
        double offsetXBottom = (player.getBoundingBox().getBBx() * 15 + player.getBoundingBox().getBBwidth() / 2)
                % (bottomBG.getWidth());
        // draw bottom bg first
        int width = (int) (topBG.getWidth() * multiplier);
        int height = (int) (topBG.getHeight() * multiplier);
        for (int i = 0; i < 3; i++) {

            g.drawImage(topBG, (int) (-offsetXTop * multiplier + width * i + horizontalPadding), verticalPadding, width,
                    height, null);

        }
        // then draw top BG

        width = (int) (bottomBG.getWidth() * multiplier);
        height = (int) (bottomBG.getHeight() * multiplier);
        for (int i = 0; i < 3; i++) {
            g.drawImage(bottomBG, (int) (-offsetXBottom * multiplier + width * i + horizontalPadding), verticalPadding,
                    width,
                    height, null);
        }
    }

}

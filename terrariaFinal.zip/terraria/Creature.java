import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.crypto.spec.DESKeySpec;

public class Creature {
    // stats
    private int health;
    private int maxHealth;

    private int damage;

    // so you cant spam to kill
    private double immunityCounter = 0;

    // movement
    private double momentumX = 0;
    private double momentumY = 0;

    // canfly
    private boolean canFly;

    // image
    private BufferedImage image;
    // rotation
    private double rotation = 0;

    // for hitbox and positioning. Contains both bounding box and normal.
    private BoundingBox boundingBox;

    // to keep track of whether it died when cleanup
    private boolean isDead = false;

    public Creature(int maxHealth, int damage, double x, double y, double width, double height, boolean canFly,
            BufferedImage image) {
        this.health = maxHealth;
        this.maxHealth = maxHealth;
        this.damage = damage;

        this.canFly = canFly;
        this.image = image;

        this.boundingBox = new BoundingBox(x, y, width, height);

    }

    public void setImage(BufferedImage image) {
        this.image = image;
    }

    public double getImmunityCounter() {
        return immunityCounter;
    }

    public void subtractImmunityCounter(double amount) {
        immunityCounter = immunityCounter-amount > 0 ? immunityCounter-amount : 0;
    }

    public void resetImmunityIncrement() {
        immunityCounter = 10;
    }

    public int getMaxHealth() {
        return maxHealth;
    }

    public void setMaxHealth(int maxHealth) {
        this.maxHealth = maxHealth;
    }

    // Getter and Setter for health
    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
        if(this.health<0) {
            this.isDead = true;
            this.health = 0;
        }
    }

    // Getter and Setter for damage
    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    // Getter and Setter for canFly
    public boolean isCanFly() {
        return canFly;
    }

    public void setCanFly(boolean canFly) {
        this.canFly = canFly;
    }

    // Getter and Setter for momentumX
    public double getMomentumX() {
        return momentumX;
    }

    public void setMomentumX(double momentumX) {
        this.momentumX = momentumX;
    }

    // Getter and Setter for momentumY
    public double getMomentumY() {
        return momentumY;
    }

    public void setMomentumY(double momentumY) {
        this.momentumY = momentumY;
    }

    // Getter and Setter for isDead
    public boolean isDead() {
        return this.isDead;
    }

    public void setIsDead(boolean isDead) {
        this.isDead = isDead;
    }

    public double getRotation() {
        return rotation;
    }

    public void setRotation(double rotation) {
        this.rotation = rotation;

        // rotate the corners to new rotation and set bounding box
        boundingBox.rotateTo(rotation);
    }

    public BufferedImage getImage() {
        return image;
    }

    public BoundingBox getBoundingBox() {
        return boundingBox;
    }

}
